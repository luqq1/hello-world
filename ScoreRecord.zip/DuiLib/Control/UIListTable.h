#ifndef __UILISTTABLE_H__
#define __UILISTTABLE_H__

#pragma once

namespace DuiLib
{
	typedef struct tagListTableInfo_s {
		int nFont;
		UINT uTextStyle;
		RECT rcTextPadding;
		DWORD dwTextColor;
		DWORD dwBkColor;
		CDuiString sBkImage;
		bool bAlternateBk;
		DWORD dwSelectedTextColor;
		DWORD dwSelectedBkColor;
		CDuiString sSelectedImage;
		DWORD dwHotTextColor;
		DWORD dwHotBkColor;
		CDuiString sHotImage;
		DWORD dwDisabledTextColor;
		DWORD dwDisabledBkColor;
		CDuiString sDisabledImage;
		DWORD dwLineColor;
		bool bShowHtml;
		bool bMultiExpandable;
	}tagListTableInfo_t;

	class UILIB_API CListTableUI : public CContainerUI
	{
	public:
		CListTableUI();

		LPCTSTR GetClass() const;
		LPVOID GetInterface(LPCTSTR pstrName);

		void SetPos(RECT rc);
		bool Add(CControlUI* pControl);
		bool AddAt(CControlUI* pControl, int iIndex);

		SIZE GetItemSize() const;
		void SetItemSize(SIZE szItem);
		int GetColumns() const;
		void SetColumns(int nCols);
		int GetRows() const;
		void SetRows(int nRows);
		void SetItemDrag(bool bDrag);
		int GetCurrentSelectItem();
		void SetCurrentSelectItem(int iSelect);
		bool IsKeyCtrlPressed();
		bool IsKeyShiftPressed();
		bool IsLeftMouseButton();
		bool IsItemDrag();
		bool IsItemSelected(int no);
		void SetMargin(RECT rc);
		HCURSOR GetItemCursor();
		void SetItemCursor(HCURSOR hCursor);
		void SetItemMachParent(bool bEnable);
		bool IsItemMachParent();
		//ʹ�ܿ�ѡ
		void EnableSelectBox(bool bEnable);
		//ʹ����Զ��ѡ
		void EnableAlwaysMutilSelect(bool bEnable);
		//ʹ�ܵ�ѡ
		void EnableAlwaysSingleSelect(bool bEnable);

		void SetItemFont(int index);
		void SetItemTextStyle(UINT uStyle);
		void SetItemTextPadding(RECT rc);
		void SetItemTextColor(DWORD dwTextColor);
		void SetItemBkColor(DWORD dwBkColor);
		void SetItemBkImage(LPCTSTR pStrImage);
		void SetAlternateBk(bool bAlternateBk);
		void SetSelectedItemTextColor(DWORD dwTextColor);
		void SetSelectedItemBkColor(DWORD dwBkColor);
		void SetSelectedItemImage(LPCTSTR pStrImage); 
		void SetHotItemTextColor(DWORD dwTextColor);
		void SetHotItemBkColor(DWORD dwBkColor);
		void SetHotItemImage(LPCTSTR pStrImage);
		void SetDisabledItemTextColor(DWORD dwTextColor);
		void SetDisabledItemBkColor(DWORD dwBkColor);
		void SetDisabledItemImage(LPCTSTR pStrImage);
		void SetItemLineColor(DWORD dwLineColor);
		bool IsItemShowHtml();
		void SetItemShowHtml(bool bShowHtml = true);
		RECT GetItemTextPadding() const;
		DWORD GetItemTextColor() const;
		DWORD GetItemBkColor() const;
		LPCTSTR GetItemBkImage() const;
		bool IsAlternateBk() const;
		DWORD GetSelectedItemTextColor() const;
		DWORD GetSelectedItemBkColor() const;
		LPCTSTR GetSelectedItemImage() const;
		DWORD GetHotItemTextColor() const;
		DWORD GetHotItemBkColor() const;
		LPCTSTR GetHotItemImage() const;
		DWORD GetDisabledItemTextColor() const;
		DWORD GetDisabledItemBkColor() const;
		LPCTSTR GetDisabledItemImage() const;
		RECT  GetItemRectByIndex(int index);
		void SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue);
		void ClearSelectBox();
		tagListTableInfo_t* GetListInfo();
		virtual void DoEvent(TEventUI& event);
		virtual void DoPaint(HDC hDC, const RECT& rcPaint);
		virtual void SetScrollPos(SIZE szPos);
		void  SetEnableDrag(bool bEnable = true);
	protected:
		void ResetScrollBar(int &xOffset, int &yOffset, POINT &ptMouse);
	protected:
		SIZE m_szItem;
		int m_nColumns;
		int m_nRows;
		int m_iCurrentClickItem;
		RECT m_rcSelectBox;
		RECT m_rcMargin;
		UINT m_uSelectBoxBorderStyle;
		DWORD m_dwSelectBoxBorderColor;
		DWORD m_dwSelectBoxColor;
		bool m_bStatusDraged;
		bool m_bEnableSelectBox;
		bool m_bEnableMutilSelectAlways;
		bool m_bEnableSingleSelectAlways;
		bool m_bItemMachParent;
		tagListTableInfo_t m_ListInfo;
		POINT m_ptEmptyClick;
		POINT m_ptMouseDragClick;
		HCURSOR m_hCursor;
		bool   m_IsInMouseLeftButton;
		SIZE   m_szChildItemPadding;
		bool   m_bEnableDrag;
	};

	class UILIB_API CListTableElementUI : public CContainerUI
	{
	public:
		CListTableElementUI();

		LPCTSTR GetClass() const;
		LPVOID GetInterface(LPCTSTR pstrName);
		
		void SetOwner(CListTableUI* pOwner);
		CListTableUI* GetOwner();
		UINT GetItemId();
		void SetItemId(UINT uId);
		UINT GetItemTag();
		void SetItemTag(UINT uTag);
		void SetToolTipDrag(LPCTSTR pstrTip);
		void SetFree(bool bFree);
		bool IsFree();
		void SetVerticalDisable( UINT len);
		UINT GetVerticalDisable( );
		virtual void DoEvent(TEventUI& event);
		virtual CDuiString GetToolTip() const;
		virtual void SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue);

		virtual void PaintStatusImage(HDC hDC);
		virtual void PaintText(HDC hDC);
		UINT             m_uVerticalDisable;

	protected:
		CListTableUI*    m_pOwner;
		CDuiString       m_sToolTipDrag;
		UINT             m_uItemId;
		UINT             m_uItemTag;
		bool             m_bFree;
		bool             m_ElementNoMouse;
	public:
		UINT m_uButtonState;
		CEventSource OnTableElementEvent;
	};
}
 
#endif // __UILISTTABLE_H__
