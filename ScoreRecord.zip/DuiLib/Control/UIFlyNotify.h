#ifndef __UIFLYNOTIFY_H__
#define __UIFLYNOTIFY_H__
#pragma once
namespace DuiLib
{
	class CFlyNotifyItemUI : public CButtonUI
	{
	public:
		CFlyNotifyItemUI();
		~CFlyNotifyItemUI();
		virtual void DoPaint(HDC hDC, const RECT& rcPaint);
		void SetFade(BYTE uFade);
	private:
		BYTE m_uFade;
		bool m_bDrawItem;
	};
	class UILIB_API CFlyNotifyExUI : public CContainerUI
	{
	public:
		CFlyNotifyExUI();
		virtual LPCTSTR GetClass() const;
		virtual LPVOID GetInterface(LPCTSTR pstrName);
		virtual void DoEvent(TEventUI& event);
		virtual void SetVisible(bool bVisible = true);
		virtual void SetText(LPCTSTR pstrText);
		virtual CDuiString GetText() const;
		virtual void SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue);
	protected:
		DWORD m_dwMaskColor;
		int   m_iStopPercent;
		int   m_iTimeEnter;
		int   m_iTimeStop;
		int   m_iTimeLeave;
		int   m_iDir;
		int   m_iCount;
		bool  m_bMove;
		SIZE  m_szItem;
		CFlyNotifyItemUI*  m_pItem;
	};
}
#endif