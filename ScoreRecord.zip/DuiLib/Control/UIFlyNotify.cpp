#include "stdafx.h"
#include "UIFlyNotify.h"
#define DIR_LEFT_RIGHT 0
#define DIR_TOP_BOTTOM 1
#define DIR_RIGHT_LEFT 2
#define DIR_BOTTOM_TOP 3
#define DIR_RETURN     4
#define TIMER_ID       17
namespace DuiLib
{
	CFlyNotifyItemUI::CFlyNotifyItemUI()
	{
		m_uFade = 0XFF;
		m_bDrawItem = true;
	}
	CFlyNotifyItemUI::~CFlyNotifyItemUI()
	{

	}
	void CFlyNotifyItemUI::SetFade(BYTE uFade)
	{
		m_uFade = uFade;
	}
	void CFlyNotifyItemUI::DoPaint(HDC hDC, const RECT& rcPaint)
	{
		if (m_bDrawItem) {
			m_bDrawItem = false;
			CButtonUI* pItem = this;
			HBITMAP hBitmap = CRenderEngine::GenerateBitmap(m_pManager, pItem, rcPaint);
			RECT rcCorner = {0};
			RECT rcBmp = {0,0,rcPaint.right - rcPaint.left, rcPaint.bottom - rcPaint.top};
			CRenderEngine::DrawImage(hDC, hBitmap, rcPaint, rcPaint, rcBmp, rcCorner, true, m_uFade);
			::DeleteObject(hBitmap);
			PaintText(hDC);
			m_bDrawItem = true;
		} else {
			CButtonUI::DoPaint(hDC, rcPaint);
		}	
	}
	CFlyNotifyExUI::CFlyNotifyExUI()
	{
		m_dwMaskColor = 0;
		m_iStopPercent = 50;
		m_iDir = DIR_LEFT_RIGHT;
		m_iTimeEnter = 20;
		m_iTimeStop = 20;
		m_iTimeLeave = 10;
		m_iCount = 0;
		m_szItem.cx = 0;
		m_szItem.cy = 0;
		m_bMove = false;
		m_pItem = new CFlyNotifyItemUI;
		ASSERT(m_pItem);
		Add(m_pItem);
		m_pItem->SetFloat(true);
		m_pItem->SetMouseEnabled(false);
	}
	LPCTSTR CFlyNotifyExUI::GetClass() const 
	{
		return _T("FlyNotifyExUI");
	}
	LPVOID CFlyNotifyExUI::GetInterface(LPCTSTR pstrName)
	{
		if( _tcscmp(pstrName, DUI_CTR_FLYNOTIFYEX) == 0 ) return static_cast<CFlyNotifyExUI*>(this);
		return CContainerUI::GetInterface(pstrName);
	}
	void CFlyNotifyExUI::DoEvent(TEventUI& event)
	{
		if (event.Type == UIEVENT_TIMER && event.wParam == TIMER_ID && m_bMove) {
			m_iCount++;
			if (m_iCount <= m_iTimeEnter) {
				BYTE dwColor = 0XFF * (m_iCount) / m_iTimeEnter;
				//dwColor <<= 24;
				RECT rc = {0};
				int step = 0;
				int iDir = m_iDir & ~DIR_RETURN;
				if (iDir & DIR_TOP_BOTTOM) {
					if (iDir == DIR_BOTTOM_TOP) {
						step = (m_cxyFixed.cy - m_iStopPercent - m_szItem.cy) * m_iCount / m_iTimeEnter;
						rc.top = m_cxyFixed.cy - m_szItem.cy - step;
					} else {
						step = m_iStopPercent * m_iCount / m_iTimeEnter;
						rc.top = step;
					}
				} else {
					if (iDir == DIR_RIGHT_LEFT) {
						step = (m_cxyFixed.cx - m_iStopPercent - m_szItem.cx) * m_iCount / m_iTimeEnter;
						rc.left = m_cxyFixed.cx - m_szItem.cx - step;
					} else {
						step = m_iStopPercent * m_iCount / m_iTimeEnter;
						rc.left = step;
					}
				}
				rc.left += m_rcItem.left;
				rc.top += m_rcItem.top;
				rc.right = rc.left + m_szItem.cx;
				rc.bottom = rc.top + m_szItem.cy;
				if (m_pItem) {
					m_pItem->SetPos(rc);
					m_pItem->SetFade(dwColor);
					m_pItem->NeedUpdate();
				}
			} else if (m_iCount <= m_iTimeEnter + m_iTimeStop) {
				if (m_pItem) {
					m_pItem->SetFade(0xff);
					m_pItem->NeedUpdate();
				}
			} else if (m_iCount <= m_iTimeEnter + m_iTimeStop + m_iTimeLeave) {
				int iPercent = m_iCount - m_iTimeEnter - m_iTimeStop;
				BYTE dwColor = 0XFF * (m_iTimeLeave - iPercent) / m_iTimeLeave;
				//dwColor <<= 24;
				RECT rc = {0};
				int step = 0;
				if (m_iDir & DIR_RETURN) {
					int iDir = m_iDir & ~DIR_RETURN;
					if (iDir & DIR_TOP_BOTTOM) {
						if (iDir == DIR_BOTTOM_TOP) {
							step = (m_cxyFixed.cy - m_iStopPercent - m_szItem.cy) * iPercent / m_iTimeEnter;
							rc.top = m_cxyFixed.cy - m_szItem.cy - m_iStopPercent + step;
						} else {
							step = m_iStopPercent * iPercent / m_iTimeEnter;
							rc.top = m_iStopPercent - step;
						}
					} else {
						if (iDir == DIR_RIGHT_LEFT) {
							step = (m_cxyFixed.cx - m_iStopPercent - m_szItem.cx) * iPercent / m_iTimeEnter;
							rc.left = m_cxyFixed.cx - m_szItem.cx - m_iStopPercent + step;
						} else {
							step = m_iStopPercent * iPercent / m_iTimeEnter;
							rc.left = m_iStopPercent - step;
						}
					}
				} else {
					if (m_iDir & DIR_TOP_BOTTOM) {
						if (m_iDir == DIR_BOTTOM_TOP) {
							step = m_iStopPercent * (m_iTimeLeave - iPercent) / m_iTimeLeave;;
							rc.top = step;
						} else {
							step = (m_cxyFixed.cy - m_szItem.cy - m_iStopPercent) * (m_iTimeLeave - iPercent) / m_iTimeLeave;
							rc.top = m_cxyFixed.cy - m_szItem.cy - step;
						}
					} else {
						if (m_iDir == DIR_RIGHT_LEFT) {
							step = m_iStopPercent * (m_iTimeLeave - iPercent) / m_iTimeLeave;;
							rc.top = step;
						} else {
							step = (m_cxyFixed.cx - m_szItem.cx - m_iStopPercent) * (m_iTimeLeave - iPercent) / m_iTimeLeave;
							rc.top = m_cxyFixed.cx - m_szItem.cx - step;
						}
					}
				}
				rc.left += m_rcItem.left;
				rc.top += m_rcItem.top;
				rc.right = rc.left + m_szItem.cx;
				rc.bottom = rc.top + m_szItem.cy;
				if (m_pItem) {
					m_pItem->SetPos(rc);
					m_pItem->SetFade(dwColor);
					m_pItem->NeedUpdate();
				}
			} else {
				SetVisible(false);
			}
			Invalidate();
			return;
		}
		CContainerUI::DoEvent(event);
	}
	void CFlyNotifyExUI::SetVisible(bool bVisible) {
		CContainerUI::SetVisible(bVisible);
		m_bMove = bVisible;
		if (bVisible) {
			m_iCount = 0;
			if (m_iDir & DIR_TOP_BOTTOM) {
				if (m_iStopPercent < 0) {
					m_iStopPercent = 0;
				} else if (m_iStopPercent > m_cxyFixed.cy - m_szItem.cy) {
					m_iStopPercent = m_cxyFixed.cy - m_szItem.cy;
				}
			} else {
				if (m_iStopPercent < 0) {
					m_iStopPercent = 0;
				} else if (m_iStopPercent > m_cxyFixed.cx - m_szItem.cx) {
					m_iStopPercent = m_cxyFixed.cx - m_szItem.cx;
				}
			}
			if (m_iTimeEnter == 0) {
				m_iTimeEnter = 1;
			}
			if (m_iTimeLeave == 0) {
				m_iTimeLeave = 1;
			}
			m_pManager->SetTimer(this, TIMER_ID, 10);
		} else {
			m_pManager->KillTimer(this, TIMER_ID);
		}
	}
	void CFlyNotifyExUI::SetText(LPCTSTR pstrText)
	{
		if (m_pItem) {
			m_pItem->SetText(pstrText);
		}
	}
	CDuiString CFlyNotifyExUI::GetText() const
	{
		if (m_pItem) {
			return m_pItem->GetText();
		}
		return _T("");
	}
	void CFlyNotifyExUI::SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue)
	{
		if(_tcscmp(pstrName, _T("itemsize")) == 0) {
			LPTSTR pstr = NULL;
			m_szItem.cx = _tcstol(pstrValue, &pstr, 10);  ASSERT(pstr);    
			m_szItem.cy = _tcstol(pstr + 1, &pstr, 10);    ASSERT(pstr);
			if (m_pItem) {
				m_pItem->SetFixedWidth(m_szItem.cx);
				m_pItem->SetFixedHeight(m_szItem.cy);
			}
		} else if(_tcscmp(pstrName, _T("itembkimage")) == 0) {
			if (m_pItem) {
				m_pItem->SetBkImage(pstrValue);
			}
		} else if(_tcscmp(pstrName, _T("showhtml")) == 0) {
			if (m_pItem) {
				m_pItem->SetAttribute(pstrName, pstrValue);
			}
		} else if(_tcscmp(pstrName, _T("textpadding")) == 0) {
			if (m_pItem) {
				m_pItem->SetAttribute(pstrName, pstrValue);
			}
		} else if(_tcscmp(pstrName, _T("align")) == 0) {
			if (m_pItem) {
				m_pItem->SetAttribute(pstrName, pstrValue);
			}
		} else if(_tcscmp(pstrName, _T("valign")) == 0) {
			if (m_pItem) {
				m_pItem->SetAttribute(pstrName, pstrValue);
			}
		} else if(_tcscmp(pstrName, _T("textcolor")) == 0) {
			if (m_pItem) {
				m_pItem->SetAttribute(pstrName, pstrValue);
			}
		} else if(_tcscmp(pstrName, _T("normalimage")) == 0) {
			if (m_pItem) {
				m_pItem->SetAttribute(pstrName, pstrValue);
			}
		} else if(_tcscmp(pstrName, _T("offset")) == 0) {
			m_iStopPercent = _ttoi(pstrValue);
		} else if(_tcscmp(pstrName, _T("enter")) == 0) {
			m_iTimeEnter = _ttoi(pstrValue);
			if (m_iTimeEnter <= 0) {
				m_iTimeEnter = 1;
			}
		} else if(_tcscmp(pstrName, _T("stop")) == 0) {
			m_iTimeStop = _ttoi(pstrValue);
			if (m_iTimeStop <= 0) {
				m_iTimeStop = 1;
			}
		} else if(_tcscmp(pstrName, _T("leave")) == 0) {
			m_iTimeLeave = _ttoi(pstrValue);
			if (m_iTimeLeave <= 0) {
				m_iTimeLeave = 1;
			}
		} else if(_tcscmp(pstrName, _T("mask")) == 0) {
			DWORD dwMask = _ttoi(pstrValue);
			if (dwMask > 255) {
				dwMask = 255;
			}
			m_dwMaskColor = dwMask;
		} else if(_tcscmp(pstrName, _T("dir")) == 0) {
			CDuiString strDir = pstrValue;
			if (strDir.Find(_T("top")) != -1) {
				m_iDir = DIR_TOP_BOTTOM;
			} else if (strDir.Find(_T("right")) != -1) {
				m_iDir = DIR_RIGHT_LEFT;
			} else if (strDir.Find(_T("bottom")) != -1) {
				m_iDir = DIR_BOTTOM_TOP;
			} else {
				m_iDir = DIR_LEFT_RIGHT;
			}
			if (strDir.Find(_T("back")) != -1) {
				m_iDir |= DIR_RETURN;
			}
		} else {
			return CContainerUI::SetAttribute(pstrName, pstrValue);
		}
	}
}