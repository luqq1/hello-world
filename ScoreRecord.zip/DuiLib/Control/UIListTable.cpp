#include "stdafx.h"
#include "UIListTable.h"

#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0)

namespace DuiLib
{
	CListTableUI::CListTableUI() : m_nColumns(0), m_nRows(0)
	{
		m_szItem.cx = m_szItem.cy = 100;
		m_ListInfo.nFont = -1;
		m_ListInfo.uTextStyle = DT_VCENTER; // m_uTextStyle(DT_VCENTER | DT_END_ELLIPSIS)
		m_ListInfo.dwTextColor = 0xFF000000;
		m_ListInfo.dwBkColor = 0;
		m_ListInfo.bAlternateBk = false;
		m_ListInfo.dwSelectedTextColor = 0xFF000000;
		m_ListInfo.dwSelectedBkColor = 0xFFC1E3FF;
		m_ListInfo.dwHotTextColor = 0xFF000000;
		m_ListInfo.dwHotBkColor = 0xFFE9F5FF;
		m_ListInfo.dwDisabledTextColor = 0xFFCCCCCC;
		m_ListInfo.dwDisabledBkColor = 0xFFFFFFFF;
		m_ListInfo.dwLineColor = 0;
		m_ListInfo.bShowHtml = false;
		m_ListInfo.bMultiExpandable = false;
		m_IsInMouseLeftButton = false;
		::ZeroMemory(&m_ListInfo.rcTextPadding, sizeof(m_ListInfo.rcTextPadding));
		m_iCurrentClickItem = -1;
		m_szChildItemPadding.cx = -1;
		m_szChildItemPadding.cy = -1;
		::ZeroMemory(&m_rcSelectBox, sizeof(m_rcSelectBox));
		::ZeroMemory(&m_rcMargin, sizeof(m_rcMargin));
		m_uSelectBoxBorderStyle = 2;
		m_dwSelectBoxBorderColor = 0xFF000000;
		m_dwSelectBoxColor = 0;
		m_bStatusDraged = false;
		m_bMenuUsed = true;
		m_bEnableSelectBox = true;
		m_bEnableMutilSelectAlways = false;
		m_bEnableSingleSelectAlways = false;
		m_hCursor = NULL;
		m_bItemMachParent = false;
		m_bEnableDrag = true;
	}
	
	LPCTSTR CListTableUI::GetClass() const
	{
		return _T("ListTableUI");
	}

	LPVOID CListTableUI::GetInterface( LPCTSTR pstrName )
	{
		if( _tcscmp(pstrName, DUI_CTR_LISTTABLE) == 0 ) return static_cast<CListTableUI*>(this);
		return CContainerUI::GetInterface(pstrName);
	}

	void CListTableUI::SetPos( RECT rc )
	{
		CControlUI::SetPos(rc);
		rc = m_rcItem;

		// Adjust for inset
		rc.left += m_rcInset.left;
		rc.top += m_rcInset.top;
		rc.right -= m_rcInset.right;
		rc.bottom -= m_rcInset.bottom;

		int ChildPadding_x = m_iChildPadding;
		int ChildPadding_y = m_iChildPadding;

		if (m_szChildItemPadding.cx != -1) {
			ChildPadding_x = m_szChildItemPadding.cx;
		} 

		if (m_szChildItemPadding.cy != -1) {
			ChildPadding_y = m_szChildItemPadding.cy;
		} 

		int nItemCount = 0;
		for (int i = 0; i < m_items.GetSize(); i++) {
			CControlUI* pControl = static_cast<CControlUI*>(m_items[i]);
			if (pControl->IsVisible() && !pControl->IsFloat()) {
				nItemCount++;
			}
		}

		if( nItemCount == 0) {
			ProcessScrollBar(rc, 0, 0);
			return;
		}

		if( m_pVerticalScrollBar && m_pVerticalScrollBar->IsVisible() ) rc.right -= m_pVerticalScrollBar->GetFixedWidth();
		if( m_pHorizontalScrollBar && m_pHorizontalScrollBar->IsVisible() ) rc.bottom -= m_pHorizontalScrollBar->GetFixedHeight();

		int cxNeed = 0;
		int cyNeed = 0;
		int nColumns = 1;
		int nRows = 1;
		SIZE szAvaibled = {rc.right - rc.left - m_rcMargin.left - m_rcMargin.right, rc.bottom - rc.top - m_rcMargin.top - m_rcMargin.bottom};
		//��ֱ�б�
		if (m_nColumns == 1 && m_bItemMachParent) {
			m_szItem.cx = szAvaibled.cx;
		} else if (m_nRows == 1 && m_bItemMachParent) {
			m_szItem.cy = szAvaibled.cy;
		}
		if (m_szItem.cx <= 0) {
			m_szItem.cx = 100;
		}
		if (m_szItem.cy <= 0) {
			m_szItem.cy = 100;
		}
		if (m_nColumns < 0) m_nColumns = 0;
		if (m_nRows < 0) m_nRows = 0;
		if (m_nColumns == 0 && m_nRows == 0) {
			//��δָ������ֱ����Ӧ
			if (szAvaibled.cx > m_szItem.cx) {
				nColumns = (szAvaibled.cx + ChildPadding_x) / (m_szItem.cx + ChildPadding_x);
			}
			nRows = (nItemCount + nColumns - 1) / nColumns;
		} else if (m_nColumns == 0) {
			//ˮƽ����Ӧ
			nColumns = (nItemCount + m_nRows - 1) / m_nRows;
			nRows = m_nRows;
		} else {
			nColumns = m_nColumns;
			nRows = (nItemCount + nColumns - 1) / nColumns;
		}
		cxNeed = (m_szItem.cx * nColumns) + ((nColumns - 1) * ChildPadding_x);
		cyNeed = (m_szItem.cy * nRows) + ((nRows - 1) * ChildPadding_y);
		cxNeed = cxNeed + m_rcMargin.left + m_rcMargin.right;
		cyNeed = cyNeed + m_rcMargin.top + m_rcMargin.bottom;
		int it2 = 0;
		int xOff = 0;
		int yOff = 0;
		if (m_pVerticalScrollBar && m_pVerticalScrollBar->IsVisible()) yOff = m_pVerticalScrollBar->GetScrollPos();
		if (m_pHorizontalScrollBar && m_pHorizontalScrollBar->IsVisible()) xOff = m_pHorizontalScrollBar->GetScrollPos();
		for (int i = 0; i < m_items.GetSize(); i++) {
			CControlUI* pControl = static_cast<CControlUI*>(m_items[i]);
			if( !pControl->IsVisible() ) continue;
			if( pControl->IsFloat() ) continue;
			int x = (it2 % nColumns) * (m_szItem.cx + ChildPadding_x) - xOff + rc.left + m_rcMargin.left;
			int y = (it2 / nColumns) * (m_szItem.cy + ChildPadding_y) - yOff + rc.top + m_rcMargin.top;
			int cx = m_szItem.cx;
			int cy = m_szItem.cy;
			if (pControl->GetFixedWidth() > 0 && cx > pControl->GetFixedWidth()) {
				cx = pControl->GetFixedWidth();
			}
			if (pControl->GetFixedHeight() > 0 && cy > pControl->GetFixedHeight()) {
				cy = pControl->GetFixedHeight();
			}
			RECT rcTmp = {x, y, x + cx, y + cy};
			pControl->SetPos(rcTmp);
			it2++;
		}
		ProcessScrollBar(rc, cxNeed, cyNeed);
	}

	SIZE CListTableUI::GetItemSize() const
	{
		return m_szItem;
	}

	void CListTableUI::SetItemSize( SIZE szItem )
	{
		if( m_szItem.cx != szItem.cx || m_szItem.cy != szItem.cy ) {
			m_szItem = szItem;
			NeedUpdate();
		}
	}

	int CListTableUI::GetColumns() const
	{
		return m_nColumns;
	}

	void CListTableUI::SetColumns( int nCols )
	{
		if( nCols <= 0 ) return;
		m_nColumns = nCols;
		NeedUpdate();
	}

	int CListTableUI::GetRows() const
	{
		return m_nRows;
	}

	void CListTableUI::SetRows( int nRows )
	{
		if (nRows < 0) return;
		m_nRows = nRows;
		NeedUpdate();
	}

	void CListTableUI::SetAttribute( LPCTSTR pstrName, LPCTSTR pstrValue )
	{
		if( _tcscmp(pstrName, _T("itemsize")) == 0 ) {
			SIZE szItem = { 0 };
			LPTSTR pstr = NULL;
			szItem.cx = _tcstol(pstrValue, &pstr, 10);  ASSERT(pstr);    
			szItem.cy = _tcstol(pstr + 1, &pstr, 10);   ASSERT(pstr);     
			SetItemSize(szItem);
		}
		else if( _tcscmp(pstrName, _T("columns")) == 0 ) SetColumns(_ttoi(pstrValue));
		else if( _tcscmp(pstrName, _T("rows")) == 0 ) SetRows(_ttoi(pstrValue));
		else if( _tcscmp(pstrName, _T("itemfont")) == 0 ) m_ListInfo.nFont = _ttoi(pstrValue);
		else if( _tcscmp(pstrName, _T("itemalign")) == 0 ) {
			if( _tcsstr(pstrValue, _T("left")) != NULL ) {
				m_ListInfo.uTextStyle &= ~(DT_CENTER | DT_RIGHT);
				m_ListInfo.uTextStyle |= DT_LEFT;
			}
			if( _tcsstr(pstrValue, _T("center")) != NULL ) {
				m_ListInfo.uTextStyle &= ~(DT_LEFT | DT_RIGHT);
				m_ListInfo.uTextStyle |= DT_CENTER;
			}
			if( _tcsstr(pstrValue, _T("right")) != NULL ) {
				m_ListInfo.uTextStyle &= ~(DT_LEFT | DT_CENTER);
				m_ListInfo.uTextStyle |= DT_RIGHT;
			}
		}
		else if( _tcscmp(pstrName, _T("itemvalign")) == 0 ) {
			if( _tcsstr(pstrValue, _T("top")) != NULL ) {
				m_ListInfo.uTextStyle &= ~(DT_VCENTER | DT_BOTTOM);
				m_ListInfo.uTextStyle |= DT_TOP;
			}
			if( _tcsstr(pstrValue, _T("vcenter")) != NULL ) {
				m_ListInfo.uTextStyle &= ~(DT_TOP | DT_BOTTOM);
				m_ListInfo.uTextStyle |= DT_VCENTER;
			}
			if( _tcsstr(pstrValue, _T("bottom")) != NULL ) {
				m_ListInfo.uTextStyle &= ~(DT_VCENTER | DT_TOP);
				m_ListInfo.uTextStyle |= DT_BOTTOM;
			}
		}
		else if( _tcscmp(pstrName, _T("itemendellipsis")) == 0 ) {
			if( _tcscmp(pstrValue, _T("true")) == 0 ) m_ListInfo.uTextStyle |= DT_END_ELLIPSIS;
			else m_ListInfo.uTextStyle &= ~DT_END_ELLIPSIS;
		}    
		else if( _tcscmp(pstrName, _T("itemtextpadding")) == 0 ) {
			RECT rcTextPadding = { 0 };
			LPTSTR pstr = NULL;
			rcTextPadding.left = _tcstol(pstrValue, &pstr, 10);  ASSERT(pstr);    
			rcTextPadding.top = _tcstol(pstr + 1, &pstr, 10);    ASSERT(pstr);    
			rcTextPadding.right = _tcstol(pstr + 1, &pstr, 10);  ASSERT(pstr);    
			rcTextPadding.bottom = _tcstol(pstr + 1, &pstr, 10); ASSERT(pstr);    
			SetItemTextPadding(rcTextPadding);
		}
		else if( _tcscmp(pstrName, _T("itemtextcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetItemTextColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itembkcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetItemBkColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itembkimage")) == 0 ) SetItemBkImage(pstrValue);
		else if( _tcscmp(pstrName, _T("itemaltbk")) == 0 ) SetAlternateBk(_tcscmp(pstrValue, _T("true")) == 0);
		else if( _tcscmp(pstrName, _T("itemselectedtextcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetSelectedItemTextColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itemselectedbkcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetSelectedItemBkColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itemselectedimage")) == 0 ) SetSelectedItemImage(pstrValue);
		else if( _tcscmp(pstrName, _T("itemhottextcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetHotItemTextColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itemhotbkcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetHotItemBkColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itemhotimage")) == 0 ) SetHotItemImage(pstrValue);
		else if( _tcscmp(pstrName, _T("itemdisabledtextcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetDisabledItemTextColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itemdisabledbkcolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetDisabledItemBkColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itemdisabledimage")) == 0 ) SetDisabledItemImage(pstrValue);
		else if( _tcscmp(pstrName, _T("itemlinecolor")) == 0 ) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			SetItemLineColor(clrColor);
		}
		else if( _tcscmp(pstrName, _T("itemshowhtml")) == 0 ) SetItemShowHtml(_tcscmp(pstrValue, _T("true")) == 0);
		else if (_tcscmp(pstrName, _T("selectbordercolor")) == 0) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			m_dwSelectBoxBorderColor = clrColor;
		} else if (_tcscmp(pstrName, _T("selectboxcolor")) == 0) {
			if( *pstrValue == _T('#')) pstrValue = ::CharNext(pstrValue);
			LPTSTR pstr = NULL;
			DWORD clrColor = _tcstoul(pstrValue, &pstr, 16);
			m_dwSelectBoxColor = clrColor;
		}else if (_tcscmp(pstrName, _T("selectborderstyle")) == 0) {
			m_uSelectBoxBorderStyle = _ttoi(pstrValue);
		} else if( _tcscmp(pstrName, _T("margin")) == 0 ) {
			RECT rcTextPadding = { 0 };
			LPTSTR pstr = NULL;
			rcTextPadding.left = _tcstol(pstrValue, &pstr, 10);  ASSERT(pstr);    
			rcTextPadding.top = _tcstol(pstr + 1, &pstr, 10);    ASSERT(pstr);    
			rcTextPadding.right = _tcstol(pstr + 1, &pstr, 10);  ASSERT(pstr);    
			rcTextPadding.bottom = _tcstol(pstr + 1, &pstr, 10); ASSERT(pstr);    
			SetMargin(rcTextPadding);
		}
		else if( _tcscmp(pstrName, _T("selectbox")) == 0 ) EnableSelectBox(_tcscmp(pstrValue, _T("true")) == 0);
		else if( _tcscmp(pstrName, _T("alwaysmutilsel")) == 0 ) EnableAlwaysMutilSelect(_tcscmp(pstrValue, _T("true")) == 0);
		else if( _tcscmp(pstrName, _T("alwayssinglesel")) == 0 ) EnableAlwaysSingleSelect(_tcscmp(pstrValue, _T("true")) == 0);
		else if( _tcscmp(pstrName, _T("machparent")) == 0 ) SetItemMachParent(_tcscmp(pstrValue, _T("true")) == 0);
		else if( _tcscmp(pstrName, _T("childitempadding")) == 0 ) {
			SIZE szChildPadding = { 0 };
			LPTSTR pstr = NULL;
			szChildPadding.cx = _tcstol(pstrValue, &pstr, 10);  ASSERT(pstr);    
			szChildPadding.cy = _tcstol(pstr + 1, &pstr, 10);    ASSERT(pstr);       
			m_szChildItemPadding = szChildPadding;
		}
		else CContainerUI::SetAttribute(pstrName, pstrValue);
	}

	bool CListTableUI::Add( CControlUI* pControl )
	{
		if (pControl && pControl->GetInterface(DUI_CTR_LISTTABLEELEMENT) ) {
			static_cast<CListTableElementUI*>(pControl)->SetOwner(this);
			return CContainerUI::Add(pControl);
		}
		return false;
	}

	bool CListTableUI::AddAt( CControlUI* pControl, int iIndex )
	{
		if (pControl && pControl->GetInterface(DUI_CTR_LISTTABLEELEMENT)) {
			static_cast<CListTableElementUI*>(pControl)->SetOwner(this);
			return CContainerUI::AddAt(pControl, iIndex);
		}
		return false;
	}

	tagListTableInfo_t* CListTableUI::GetListInfo()
	{
		return &m_ListInfo;
	}

	void CListTableUI::SetItemFont( int index )
	{
		m_ListInfo.nFont = index;
		NeedUpdate();
	}

	void CListTableUI::SetItemTextStyle( UINT uStyle )
	{
		m_ListInfo.uTextStyle = uStyle;
		NeedUpdate();
	}

	void CListTableUI::SetItemTextPadding( RECT rc )
	{
		m_ListInfo.rcTextPadding = rc;
		NeedUpdate();
	}

	void CListTableUI::SetItemTextColor( DWORD dwTextColor )
	{
		m_ListInfo.dwTextColor = dwTextColor;
		Invalidate();
	}

	void CListTableUI::SetItemBkColor( DWORD dwBkColor )
	{
		m_ListInfo.dwBkColor = dwBkColor;
		Invalidate();
	}

	void CListTableUI::SetItemBkImage( LPCTSTR pStrImage )
	{
		m_ListInfo.sBkImage = pStrImage;
		Invalidate();
	}

	void CListTableUI::SetAlternateBk( bool bAlternateBk )
	{
		m_ListInfo.bAlternateBk = bAlternateBk;
		Invalidate();
	}

	void CListTableUI::SetSelectedItemTextColor( DWORD dwTextColor )
	{
		m_ListInfo.dwSelectedTextColor = dwTextColor;
		Invalidate();
	}

	void CListTableUI::SetSelectedItemBkColor( DWORD dwBkColor )
	{
		m_ListInfo.dwSelectedBkColor = dwBkColor;
		Invalidate();
	}

	void CListTableUI::SetSelectedItemImage( LPCTSTR pStrImage )
	{
		m_ListInfo.sSelectedImage = pStrImage;
		Invalidate();
	}

	void CListTableUI::SetHotItemTextColor( DWORD dwTextColor )
	{
		m_ListInfo.dwHotTextColor = dwTextColor;
		Invalidate();
	}

	void CListTableUI::SetHotItemBkColor( DWORD dwBkColor )
	{
		m_ListInfo.dwHotBkColor = dwBkColor;
		Invalidate();
	}

	void CListTableUI::SetHotItemImage( LPCTSTR pStrImage )
	{
		m_ListInfo.sHotImage = pStrImage;
		Invalidate();
	}

	void CListTableUI::SetDisabledItemTextColor( DWORD dwTextColor )
	{
		m_ListInfo.dwDisabledTextColor = dwTextColor;
		Invalidate();
	}

	void CListTableUI::SetDisabledItemBkColor( DWORD dwBkColor )
	{
		m_ListInfo.dwDisabledBkColor = dwBkColor;
		Invalidate();
	}

	void CListTableUI::SetDisabledItemImage( LPCTSTR pStrImage )
	{
		m_ListInfo.sDisabledImage = pStrImage;
		Invalidate();
	}

	void CListTableUI::SetItemLineColor( DWORD dwLineColor )
	{
		m_ListInfo.dwLineColor = dwLineColor;
		Invalidate();
	}

	bool CListTableUI::IsItemShowHtml()
	{
		return m_ListInfo.bShowHtml;
	}

	void CListTableUI::SetItemShowHtml( bool bShowHtml /*= true*/ )
	{
		if( m_ListInfo.bShowHtml == bShowHtml ) return;

		m_ListInfo.bShowHtml = bShowHtml;
		NeedUpdate();
	}

	RECT CListTableUI::GetItemTextPadding() const
	{
		return m_ListInfo.rcTextPadding;
	}

	DWORD CListTableUI::GetItemTextColor() const
	{
		return m_ListInfo.dwTextColor;
	}

	DWORD CListTableUI::GetItemBkColor() const
	{
		return m_ListInfo.dwBkColor;
	}

	LPCTSTR CListTableUI::GetItemBkImage() const
	{
		return m_ListInfo.sBkImage;
	}

	bool CListTableUI::IsAlternateBk() const
	{
		return m_ListInfo.bAlternateBk;
	}

	DWORD CListTableUI::GetSelectedItemTextColor() const
	{
		return m_ListInfo.dwSelectedTextColor;
	}

	DWORD CListTableUI::GetSelectedItemBkColor() const
	{
		return m_ListInfo.dwSelectedBkColor;
	}

	LPCTSTR CListTableUI::GetSelectedItemImage() const
	{
		return m_ListInfo.sSelectedImage;
	}

	DWORD CListTableUI::GetHotItemTextColor() const
	{
		return m_ListInfo.dwHotTextColor;
	}

	DWORD CListTableUI::GetHotItemBkColor() const
	{
		return m_ListInfo.dwHotBkColor;
	}

	LPCTSTR CListTableUI::GetHotItemImage() const
	{
		return m_ListInfo.sHotImage;
	}

	DWORD CListTableUI::GetDisabledItemTextColor() const
	{
		return m_ListInfo.dwDisabledTextColor;
	}

	DWORD CListTableUI::GetDisabledItemBkColor() const
	{
		return m_ListInfo.dwDisabledBkColor;
	}

	LPCTSTR CListTableUI::GetDisabledItemImage() const
	{
		return m_ListInfo.sDisabledImage;
	}

	void CListTableUI::DoEvent( TEventUI& event )
	{
		if (event.Type == UIEVENT_SCROLLWHEEL) {
	
		}else if (event.Type == UIEVENT_BUTTONDOWN) {
			if (!IsKeyCtrlPressed()) {
				for (int i = 0; i < m_items.GetSize(); i++) {
					CListTableElementUI* pElement = static_cast<CListTableElementUI*>(m_items[i]);
					pElement->m_uButtonState &= ~(UISTATE_PUSHED | UISTATE_CAPTURED | UISTATE_SELECTED | UISTATE_HOT);
				}
				m_IsInMouseLeftButton = true;
				m_iCurrentClickItem = -1;
				m_ptEmptyClick = event.ptMouse;
				m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMSELECT, UIEVENT_BUTTONDOWN);
				NeedUpdate();
			}
		} else if (event.Type == UIEVENT_BUTTONUP) {
			SetItemDrag(false);
			ClearSelectBox();
		} else if (event.Type == UIEVENT_MOUSEMOVE) {
			if (m_bEnableSelectBox && IsLeftMouseButton()) {
				int xOffset, yOffset;
				ResetScrollBar(xOffset, yOffset, event.ptMouse);
				m_ptEmptyClick.x -= xOffset;
				m_ptEmptyClick.y -= yOffset;
				int x = m_ptEmptyClick.x;
				int y = m_ptEmptyClick.y;
				
				RECT rc = {x, y, x, y};
				if (event.ptMouse.x < x) {
					rc.left = event.ptMouse.x;
				} else {
					rc.right = event.ptMouse.x;
				}
				if (event.ptMouse.y < y) {
					rc.top = event.ptMouse.y;
				} else {
					rc.bottom = event.ptMouse.y;
				}
				for (int i = 0; i < m_items.GetSize(); i++) {
					CListTableElementUI* pElement = static_cast<CListTableElementUI*>(m_items[i]);
					if (!pElement->IsVisible()) {
						continue;
					}
					RECT rcElement = pElement->GetPos();
					rcElement.bottom -= pElement->GetVerticalDisable();
					RECT rcTemp = { 0 };
					if(!::IntersectRect(&rcTemp, &rc, &rcElement)) {
						pElement->m_uButtonState &= ~(UISTATE_SELECTED| UISTATE_HOT);
					} else {
						pElement->m_uButtonState|= UISTATE_SELECTED;
					}
				}
				m_rcSelectBox = rc;
				m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMSELECT);
				NeedUpdate();
			} 
		}  else if (event.Type == UIEVENT_CONTEXTMENU) {
			if (event.pSender == this) {
				if (!IsKeyCtrlPressed()) {
					for (int i = 0; i < m_items.GetSize(); i++) {
						CListTableElementUI* pElement = static_cast<CListTableElementUI*>(m_items[i]);
						pElement->m_uButtonState &= ~(UISTATE_PUSHED | UISTATE_CAPTURED | UISTATE_SELECTED | UISTATE_HOT);
					}
					m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMSELECT);
				}
				CContainerUI::DoEvent(event);
			}
		    ClearSelectBox();
			return;
		}
		CContainerUI::DoEvent(event);
	}

	void CListTableUI::SetItemDrag( bool bDrag )
	{
		m_bStatusDraged = bDrag;
		if (bDrag) {
			GetCursorPos(&m_ptMouseDragClick);		
		} else {
			m_ptMouseDragClick.x = -1;
			m_ptMouseDragClick.y = -1;
		}
	}

	int CListTableUI::GetCurrentSelectItem()
	{
		return m_iCurrentClickItem;
	}

	bool CListTableUI::IsKeyCtrlPressed()
	{
		return KEY_DOWN(VK_CONTROL);
	}

	bool CListTableUI::IsKeyShiftPressed()
	{
		return KEY_DOWN(VK_SHIFT);
	}

	void CListTableUI::SetCurrentSelectItem( int iSelect )
	{
		if (iSelect >= 0 && iSelect < m_items.GetSize()) {
			m_iCurrentClickItem = iSelect;
		}
	}

	bool CListTableUI::IsItemDrag()
	{
		if (m_bStatusDraged && m_bEnableDrag) {
			if (m_ptMouseDragClick.x == -1 || m_ptMouseDragClick.y == -1 ) {
				return false;
			}

			POINT pt;
			GetCursorPos(&pt);
			int dx , dy;
			dx = (pt.x - m_ptMouseDragClick.x) * (pt.x - m_ptMouseDragClick.x);
			dy = (pt.y - m_ptMouseDragClick.y) * (pt.y - m_ptMouseDragClick.y);

			if ( dx + dy > 10 ) {
				return true;
			} else {
				return false;
			}

		} else {
			return false;
		}

	}

	void CListTableUI::DoPaint( HDC hDC, const RECT& rcPaint )
	{
		RECT rcTemp = { 0 };
		if( !::IntersectRect(&rcTemp, &rcPaint, &m_rcItem) ) return;
		CContainerUI::DoPaint(hDC, rcPaint);
		if ( m_bEnableSelectBox && IsLeftMouseButton()) {
			if( !::IntersectRect(&rcTemp, &rcPaint, &m_rcSelectBox) ) return;
			if (m_dwSelectBoxBorderColor > 0X00FFFFFF) {
				RECT rcBorder = m_rcSelectBox;
				rcBorder.right = rcBorder.left;
				CRenderEngine::DrawLine(hDC,rcBorder,1,GetAdjustColor(m_dwSelectBoxBorderColor),m_uSelectBoxBorderStyle);
				rcBorder.right = rcBorder.left = m_rcSelectBox.right - 1;
				CRenderEngine::DrawLine(hDC,rcBorder,1,GetAdjustColor(m_dwSelectBoxBorderColor),m_uSelectBoxBorderStyle);
				rcBorder = m_rcSelectBox;
				rcBorder.bottom = rcBorder.top;
				CRenderEngine::DrawLine(hDC,rcBorder,1,GetAdjustColor(m_dwSelectBoxBorderColor),m_uSelectBoxBorderStyle);
				rcBorder.bottom = rcBorder.top = m_rcSelectBox.bottom - 1;
				CRenderEngine::DrawLine(hDC,rcBorder,1,GetAdjustColor(m_dwSelectBoxBorderColor),m_uSelectBoxBorderStyle);
			}
			if (m_dwSelectBoxColor > 0X00FFFFFF) {
				CRenderEngine::DrawColor(hDC, m_rcSelectBox, GetAdjustColor(m_dwSelectBoxColor));
			}
		}
	}

	void CListTableUI::ResetScrollBar(int &xOffset, int &yOffset, POINT &ptMouse)
	{
		int x = 0;
		int y = 0;
		int xRange = 0;
		int yRange = 0;
		xOffset = 0;
		yOffset = 0;
		if (m_pHorizontalScrollBar && m_pHorizontalScrollBar->IsVisible()) {
			x = m_pHorizontalScrollBar->GetScrollPos();
			xRange = m_pHorizontalScrollBar->GetScrollRange();
		}
		if (m_pVerticalScrollBar && m_pVerticalScrollBar->IsVisible()) {
			y = m_pVerticalScrollBar->GetScrollPos();
			yRange = m_pVerticalScrollBar->GetScrollRange();
		}
		if (ptMouse.x < m_rcItem.left + 25) {
			if (x > 25) {
				xOffset = -25;
				x -= 25;
			} else {
				xOffset = -x;
				x = 0;
			}
		} else if (ptMouse.x > m_rcItem.right - 25) {
			if (x < xRange - 25) {
				xOffset = 25;
				x += 25;
			} else {
				xOffset = xRange - x;
				x = xRange;
			}
		}
		if (ptMouse.y < m_rcItem.top + 25) {
			if (y > 25) {
				yOffset = -25;
				y -= 25;
			} else {
				yOffset = -y;
				y = 0;
			}
		} else if (ptMouse.y > m_rcItem.bottom - 25) {
			if (y < yRange - 25) {
				yOffset = 25;
				y += 25;
			} else {
				yOffset = yRange - y;
				y = yRange;
			}
		}
		if (m_pHorizontalScrollBar && m_pHorizontalScrollBar->IsVisible()) {
			m_pHorizontalScrollBar->SetScrollPos(x);
		}
		if (m_pVerticalScrollBar && m_pVerticalScrollBar->IsVisible()) {
			m_pVerticalScrollBar->SetScrollPos(y);
		}
	}

	bool CListTableUI::IsItemSelected( int no )
	{
		if (no >= 0 && no < m_items.GetSize()) {
			if (static_cast<CListTableElementUI*>(m_items[no])->m_uButtonState & UISTATE_SELECTED) {
				return true;
			}
		}
		return false;
	}

	void CListTableUI::SetMargin( RECT rc )
	{
		m_rcMargin = rc;
	}

	HCURSOR CListTableUI::GetItemCursor()
	{
		return m_hCursor;
	}

	void CListTableUI::SetItemCursor( HCURSOR hCursor )
	{
		if (hCursor == NULL) {
			if (m_hCursor) {
				::DestroyCursor(m_hCursor);
				m_hCursor = NULL;
			}
		}
		m_hCursor = hCursor;
	}

	void CListTableUI::EnableSelectBox( bool bEnable )
	{
		m_bEnableSelectBox = bEnable;
	}

	void CListTableUI::EnableAlwaysMutilSelect( bool bEnable )
	{
		m_bEnableMutilSelectAlways = bEnable;
		if (bEnable) {
		}
	}

	void CListTableUI::SetItemMachParent( bool bEnable )
	{
		m_bItemMachParent = bEnable;
	}

	bool CListTableUI::IsItemMachParent()
	{
		return m_bItemMachParent;
	}

	void CListTableUI::EnableAlwaysSingleSelect( bool bEnable )
	{
		m_bEnableSingleSelectAlways = bEnable;
	}

	RECT CListTableUI::GetItemRectByIndex( int index )
	{
		RECT resRc = {0};
		RECT rc = m_rcItem;

		// Adjust for inset
		rc.left += m_rcInset.left;
		rc.top += m_rcInset.top;
		rc.right -= m_rcInset.right;
		rc.bottom -= m_rcInset.bottom;

		int ChildPadding_x = m_iChildPadding;
		int ChildPadding_y = m_iChildPadding;

		if (m_szChildItemPadding.cx != -1) {
			ChildPadding_x = m_szChildItemPadding.cx;
		} 

		if (m_szChildItemPadding.cy != -1) {
			ChildPadding_y = m_szChildItemPadding.cy;
		} 

		int nItemCount = 0;
		for (int i = 0; i < m_items.GetSize(); i++) {
			CControlUI* pControl = static_cast<CControlUI*>(m_items[i]);
			if (pControl->IsVisible() && !pControl->IsFloat()) {
				nItemCount++;
			}		
		}

		if( m_pVerticalScrollBar && m_pVerticalScrollBar->IsVisible() ) rc.right -= m_pVerticalScrollBar->GetFixedWidth();
		if( m_pHorizontalScrollBar && m_pHorizontalScrollBar->IsVisible() ) rc.bottom -= m_pHorizontalScrollBar->GetFixedHeight();

		int cxNeed = 0;
		int cyNeed = 0;
		int nColumns = 1;
		int nRows = 1;
		SIZE szAvaibled = {rc.right - rc.left - m_rcMargin.left - m_rcMargin.right, rc.bottom - rc.top - m_rcMargin.top - m_rcMargin.bottom};
		//��ֱ�б�
		if (m_nColumns == 1 && m_bItemMachParent) {
			m_szItem.cx = szAvaibled.cx;
		} else if (m_nRows == 1 && m_bItemMachParent) {
			m_szItem.cy = szAvaibled.cy;
		}
		if (m_szItem.cx <= 0) {
			m_szItem.cx = 100;
		}
		if (m_szItem.cy <= 0) {
			m_szItem.cy = 100;
		}
		if (m_nColumns < 0) m_nColumns = 0;
		if (m_nRows < 0) m_nRows = 0;
		if (m_nColumns == 0 && m_nRows == 0) {
			//��δָ������ֱ����Ӧ
			if (szAvaibled.cx > m_szItem.cx) {
				nColumns = (szAvaibled.cx + ChildPadding_x) / (m_szItem.cx + ChildPadding_x);
			}
			nRows = (nItemCount + nColumns - 1) / nColumns;
		} else if (m_nColumns == 0) {
			//ˮƽ����Ӧ
			nColumns = (nItemCount + m_nRows - 1) / m_nRows;
			nRows = m_nRows;
		} else {
			nColumns = m_nColumns;
			nRows = (nItemCount + nColumns - 1) / nColumns;
		}
		cxNeed = (m_szItem.cx * nColumns) + ((nColumns - 1) * ChildPadding_x);
		cyNeed = (m_szItem.cy * nRows) + ((nRows - 1) * ChildPadding_y);
		cxNeed = cxNeed + m_rcMargin.left + m_rcMargin.right;
		cyNeed = cyNeed + m_rcMargin.top + m_rcMargin.bottom;
		int it2 = 0;
		int xOff = 0;
		int yOff = 0;
		if (m_pVerticalScrollBar && m_pVerticalScrollBar->IsVisible()) yOff = m_pVerticalScrollBar->GetScrollPos();
		if (m_pHorizontalScrollBar && m_pHorizontalScrollBar->IsVisible()) xOff = m_pHorizontalScrollBar->GetScrollPos();
		for (int i = 0; i < m_items.GetSize(); i++) {
			CControlUI* pControl = static_cast<CControlUI*>(m_items[i]);
			if( !pControl->IsVisible() ) continue;
			if( pControl->IsFloat() ) continue;
			int x = (it2 % nColumns) * (m_szItem.cx + ChildPadding_x) - xOff + rc.left + m_rcMargin.left;
			int y = (it2 / nColumns) * (m_szItem.cy + ChildPadding_y) - yOff + rc.top + m_rcMargin.top;
			int cx = m_szItem.cx;
			int cy = m_szItem.cy;
			if (pControl->GetFixedWidth() > 0 && cx > pControl->GetFixedWidth()) {
				cx = pControl->GetFixedWidth();
			}
			if (pControl->GetFixedHeight() > 0 && cy > pControl->GetFixedHeight()) {
				cy = pControl->GetFixedHeight();
			}
			RECT rcTmp = {x, y, x + cx, y + cy};
            if ( it2 == index) {
				resRc = rcTmp;
				break;
			}

			it2++;
		}
		return resRc;

	}

	void CListTableUI::SetScrollPos( SIZE szPos )
	{
		int cx = 0;
		int cy = 0;
		if( m_pVerticalScrollBar && m_pVerticalScrollBar->IsVisible() ) {
			int iLastScrollPos = m_pVerticalScrollBar->GetScrollPos();
			m_pVerticalScrollBar->SetScrollPos(szPos.cy);
			cy = m_pVerticalScrollBar->GetScrollPos() - iLastScrollPos;
		}

		if( m_pHorizontalScrollBar && m_pHorizontalScrollBar->IsVisible() ) {
			int iLastScrollPos = m_pHorizontalScrollBar->GetScrollPos();
			m_pHorizontalScrollBar->SetScrollPos(szPos.cx);
			cx = m_pHorizontalScrollBar->GetScrollPos() - iLastScrollPos;
		}

		if( cx == 0 && cy == 0 ) return;

		RECT rcPos;
		for( int it2 = 0; it2 < m_items.GetSize(); it2++ ) {
			CControlUI* pControl = static_cast<CControlUI*>(m_items[it2]);
			if( !pControl->IsVisible() ) continue;

			rcPos = pControl->GetPos();
			rcPos.left -= cx;
			rcPos.right -= cx;
			rcPos.top -= cy;
			rcPos.bottom -= cy;
			pControl->SetPos(rcPos);
		}

		Invalidate();
	}

	bool CListTableUI::IsLeftMouseButton()
	{
		return KEY_DOWN(VK_LBUTTON) && m_IsInMouseLeftButton;
	}

	void CListTableUI::ClearSelectBox()
	{
		m_rcSelectBox.left = 0;
		m_rcSelectBox.top = 0;
		m_rcSelectBox.right = 0;
		m_rcSelectBox.bottom = 0;
		m_IsInMouseLeftButton = false;
		NeedUpdate();
	}

	void CListTableUI::SetEnableDrag( bool bEnable /*= true*/ )
	{
		m_bEnableDrag = bEnable;
	}


	CListTableElementUI::CListTableElementUI()
	{
		m_uButtonState = 0;
		m_bMenuUsed = true;
		m_uItemId = 0;
		m_bFree = false;
		m_ElementNoMouse = false;
		m_uVerticalDisable = 0;
	}

	LPCTSTR CListTableElementUI::GetClass() const
	{
		return _T("ListTableElementUI");
	}

	LPVOID CListTableElementUI::GetInterface( LPCTSTR pstrName )
	{
		if( _tcscmp(pstrName, DUI_CTR_LISTTABLEELEMENT) == 0 ) return static_cast<CListTableElementUI*>(this);
		return CContainerUI::GetInterface(pstrName);
	}

	void CListTableElementUI::SetOwner( CListTableUI* pOwner )
	{
		m_pOwner = pOwner;
	}

	CListTableUI* CListTableElementUI::GetOwner()
	{
		return m_pOwner;
	}

	void CListTableElementUI::DoEvent( TEventUI& event )
	{
		if (m_bFree) {
			CContainerUI::DoEvent(event);
			return;
		}
		
		if (OnTableElementEvent)OnTableElementEvent(&event);
		if (event.Type != UIEVENT_MOUSELEAVE
			&&(event.ptMouse.y >= m_rcItem.bottom - m_uVerticalDisable) 
			&& event.Type != UIEVENT_MOUSEENTER
			&& event.Type != UIEVENT_BUTTONUP) {

				if ( event.Type == UIEVENT_MOUSEMOVE) {
					if( IsEnabled() ) {
						m_uButtonState &= ~UISTATE_HOT;
						Invalidate();
					}
				}

			event.pSender = m_pOwner;
		    if (m_pOwner) m_pOwner->DoEvent(event);
			return;
		}

		if (event.Type == UIEVENT_BUTTONDOWN && !m_ElementNoMouse && IsEnabled()) {
			int no = -1;
			m_uButtonState |= UISTATE_PUSHED | UISTATE_CAPTURED;
			if (m_pOwner) {
				m_pOwner->SetItemDrag(true);
				no = m_pOwner->GetItemIndex(this);
				int sel = m_pOwner->GetCurrentSelectItem(); 
				if (m_pOwner->IsKeyCtrlPressed()) {
					m_uButtonState ^= UISTATE_SELECTED;
					m_pOwner->SetCurrentSelectItem(no);
				} else if (m_pOwner->IsKeyShiftPressed()) {
					if (sel == -1) {
						m_pOwner->SetCurrentSelectItem(no);
					}
					for (int i = 0; i < m_pOwner->GetCount(); i++) {
						CListTableElementUI* pElement = static_cast<CListTableElementUI*>(m_pOwner->GetItemAt(i));
						if (i < sel && i < no) {
							pElement->m_uButtonState &= ~(UISTATE_SELECTED | UISTATE_HOT);
						} else if (i > sel && i > no) {
							pElement->m_uButtonState &= ~(UISTATE_SELECTED | UISTATE_HOT);
						} else {
							pElement->m_uButtonState |= UISTATE_SELECTED;
						}
					}
				} else if ((m_uButtonState & UISTATE_SELECTED) == 0) {
					for (int i = 0; i < m_pOwner->GetCount(); i++) {
						CListTableElementUI* pElement = static_cast<CListTableElementUI*>(m_pOwner->GetItemAt(i));
						if (pElement == this) {
							pElement->m_uButtonState |= UISTATE_SELECTED;
							m_pOwner->SetCurrentSelectItem(i);
						} else {
							pElement->m_uButtonState &= ~(UISTATE_SELECTED | UISTATE_HOT);
						}
					}
				}
				m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMSELECT, UIEVENT_BUTTONDOWN);
				m_pOwner->NeedUpdate();
			} else {
				NeedUpdate();
			}		
			return;
		} else if (event.Type == UIEVENT_BUTTONUP && !m_ElementNoMouse && IsEnabled()) {
			if( (m_uButtonState & UISTATE_CAPTURED) != 0 ) {
				if( ::PtInRect(&m_rcItem, event.ptMouse) ) Activate();
				m_uButtonState &= ~(UISTATE_PUSHED | UISTATE_CAPTURED);
				Invalidate();
			}
			if (m_pOwner) {
				bool bItemDrag = m_pOwner->IsItemDrag();
				m_pOwner->SetItemDrag(false);
				if (event.ptMouse.x >= m_rcItem.left && event.ptMouse.x <= m_rcItem.right
					&& event.ptMouse.y >= m_rcItem.top && (event.ptMouse.y <= m_rcItem.bottom - m_uVerticalDisable)) {
						if (!m_pOwner->IsKeyShiftPressed() && !m_pOwner->IsKeyCtrlPressed()) {
							for (int i = 0; i < m_pOwner->GetCount(); i++) {
								CListTableElementUI* pElement = static_cast<CListTableElementUI*>(m_pOwner->GetItemAt(i));
								if (pElement == this) {
									pElement->m_uButtonState |= UISTATE_SELECTED;
									m_pOwner->SetCurrentSelectItem(i);
								} else {
									pElement->m_uButtonState &= ~(UISTATE_SELECTED | UISTATE_HOT);
								}
							}
							m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMSELECT, UIEVENT_BUTTONUP);
							m_pOwner->NeedUpdate();
						}
				}
				if (bItemDrag) {
					POINT point = event.ptMouse;
					ClientToScreen(m_pManager->GetPaintWindow(), &point);
					HWND wnd = ::WindowFromPoint(point);
					if (wnd != m_pManager->GetPaintWindow()) {
						m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMDROP, (WPARAM)wnd);
					} else {
						CControlUI* pControl = m_pManager->FindSubControlByPoint(m_pOwner, event.ptMouse);
						if (pControl != NULL && pControl != event.pSender) {
							m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMDRAG, (WPARAM)pControl, (LPARAM)m_pOwner);
						}
					}
				}		
			}
		}
		if( event.Type == UIEVENT_MOUSEENTER && IsEnabled()) {
			if(m_pOwner && m_pOwner->IsItemDrag() || event.ptMouse.y < m_rcItem.bottom - m_uVerticalDisable ) {
				m_uButtonState |= UISTATE_HOT;
				Invalidate();
			}
			return;
		}

		if( event.Type == UIEVENT_MOUSELEAVE && !m_ElementNoMouse && IsEnabled()) {
			if( IsEnabled() ) {
				m_uButtonState &= ~UISTATE_HOT;
				Invalidate();
			}
			// return;
		}
		if (event.Type == UIEVENT_MOUSEMOVE && !m_ElementNoMouse && IsEnabled()) {
			if (m_pOwner && m_pOwner->IsItemDrag() && m_pOwner->GetItemCursor()) {
				::SetCursor(m_pOwner->GetItemCursor());
			}
			if( IsEnabled() ) {
				if (!(m_uButtonState & UISTATE_HOT)) {
					m_uButtonState |= UISTATE_HOT;
					Invalidate();
				}	
			}
		}
		if (event.Type == UIEVENT_CONTEXTMENU && !m_ElementNoMouse && IsEnabled()) {
			if ((m_uButtonState & UISTATE_SELECTED) == 0) {
				m_uButtonState |= UISTATE_SELECTED;
				if (m_pOwner) {
					for (int i = 0; i < m_pOwner->GetCount(); i++) {
						CListTableElementUI* pElement = static_cast<CListTableElementUI*>(m_pOwner->GetItemAt(i));
						if (pElement == this) {
							pElement->m_uButtonState |= UISTATE_SELECTED;
						} else {
							pElement->m_uButtonState &= ~(UISTATE_SELECTED | UISTATE_HOT);
						}
					}
					m_pManager->SendNotify(this, DUI_MSGTYPE_ITEMSELECT);
					m_pOwner->NeedUpdate();
				} else {
					NeedUpdate();
				}
			}
		}
		CContainerUI::DoEvent(event);
		if (m_pOwner) m_pOwner->DoEvent(event);

	}

	DuiLib::CDuiString CListTableElementUI::GetToolTip() const
	{
		if (m_pOwner) {
			if (m_pOwner->IsItemDrag() && (m_uButtonState & UISTATE_SELECTED) == 0) {
				return m_sToolTipDrag;
			}
		}
		return m_sToolTip;
	}

	void CListTableElementUI::PaintStatusImage( HDC hDC )
	{
		if (m_bFree) {
			return;
		}

		CDuiString dest;
		dest.Format(_T(" dest=\'%d,%d,%d,%d\'"), 0, 0, m_rcItem.right - m_rcItem.left, m_rcItem.bottom - m_rcItem.top - m_uVerticalDisable);


		if( IsFocused() ) m_uButtonState |= UISTATE_FOCUSED;
		else m_uButtonState &= ~ UISTATE_FOCUSED;
		if( !IsEnabled() ) m_uButtonState |= UISTATE_DISABLED;
		else m_uButtonState &= ~ UISTATE_DISABLED;
		if (m_pOwner) {
			tagListTableInfo_t* pInfo = m_pOwner->GetListInfo();
			if( (m_uButtonState & UISTATE_DISABLED) != 0 ) {
				if (!pInfo->sDisabledImage.IsEmpty()) {
					DrawImage(hDC, (LPCTSTR)(pInfo->sDisabledImage + dest));
				} else if (pInfo->dwDisabledBkColor != 0) {
					CRenderEngine::DrawColor(hDC, m_rcItem, GetAdjustColor(pInfo->dwDisabledBkColor));
				}
			} else if ((m_uButtonState & UISTATE_SELECTED) != 0) {
				if (!pInfo->sSelectedImage.IsEmpty()) {
					DrawImage(hDC, (LPCTSTR)(pInfo->sSelectedImage + dest));
					return;
				} else if (pInfo->dwSelectedBkColor != 0) {
					CRenderEngine::DrawColor(hDC, m_rcItem, GetAdjustColor(pInfo->dwSelectedBkColor));
					return;
				}
			} else if ((m_uButtonState & UISTATE_HOT) != 0) {
				if (!pInfo->sHotImage.IsEmpty()) {
					DrawImage(hDC, (LPCTSTR)(pInfo->sHotImage + dest));
				} else if (pInfo->dwHotBkColor != 0) {
					CRenderEngine::DrawColor(hDC, m_rcItem, GetAdjustColor(pInfo->dwHotBkColor));
				}
			}
			if (!m_sForeImage.IsEmpty()) {
				DrawImage(hDC, (LPCTSTR)m_sForeImage);
			}
		}
	}

	void CListTableElementUI::PaintText( HDC hDC )
	{
		if (m_pOwner) {
			tagListTableInfo_t* pInfo = m_pOwner->GetListInfo();
			DWORD m_dwTextColor = pInfo->dwTextColor;
			DWORD m_dwDisabledTextColor = pInfo->dwDisabledTextColor;
			RECT m_rcTextPadding = pInfo->rcTextPadding;
			RECT rc = m_rcItem;
			rc.left += m_rcTextPadding.left;
			rc.right -= m_rcTextPadding.right;
			rc.top += m_rcTextPadding.top;
			rc.bottom -= m_rcTextPadding.bottom;
			UINT m_uTextStyle = pInfo->uTextStyle;
			if( m_sText.IsEmpty() ) return;
			int nLinks = 0;
			if (m_uButtonState & UISTATE_HOT) {
				m_dwTextColor = pInfo->dwHotTextColor;
			} else if (m_uButtonState & UISTATE_SELECTED) {
				m_dwTextColor = pInfo->dwSelectedTextColor;
			}
			if( IsEnabled() ) {
				if( pInfo->bShowHtml )
					CRenderEngine::DrawHtmlText(hDC, m_pManager, rc, m_sText, m_dwTextColor, \
					NULL, NULL, nLinks, DT_SINGLELINE | m_uTextStyle);
				else
					CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, m_dwTextColor, \
					pInfo->nFont, DT_SINGLELINE | m_uTextStyle);
			}
			else {
				if( pInfo->bShowHtml )
					CRenderEngine::DrawHtmlText(hDC, m_pManager, rc, m_sText, m_dwDisabledTextColor, \
					NULL, NULL, nLinks, DT_SINGLELINE | m_uTextStyle);
				else
					CRenderEngine::DrawText(hDC, m_pManager, rc, m_sText, m_dwDisabledTextColor, \
					pInfo->nFont, DT_SINGLELINE | m_uTextStyle);
			}
		}		
	}

	void CListTableElementUI::SetAttribute( LPCTSTR pstrName, LPCTSTR pstrValue )
	{
		if( _tcscmp(pstrName, _T("tooltipdrag")) == 0 ) SetToolTipDrag(pstrValue);
		else if( _tcscmp(pstrName, _T("foreimage")) == 0 ) m_sForeImage = pstrValue;
		else if( _tcscmp(pstrName, _T("free")) == 0 ) SetFree(_tcscmp(pstrValue, _T("true")) == 0);
		else if( _tcscmp(pstrName, _T("verticaldisable")) == 0 ) m_uVerticalDisable = _ttoi(pstrValue);
		else if( _tcscmp(pstrName, _T("elementnomouse")) == 0 ) {if (_tcscmp(pstrValue, _T("true")) == 0) {m_ElementNoMouse = true;}}


		else CContainerUI::SetAttribute(pstrName, pstrValue);
	}

	UINT CListTableElementUI::GetItemId()
	{
		return m_uItemId;
	}

	void CListTableElementUI::SetItemId( UINT uId )
	{
		m_uItemId = uId;
	}

	void CListTableElementUI::SetToolTipDrag( LPCTSTR pstrTip )
	{
		m_sToolTipDrag = pstrTip;
	}

	void CListTableElementUI::SetFree( bool bFree )
	{
		m_bFree = bFree;
	}

	bool CListTableElementUI::IsFree()
	{
		return m_bFree;
	}

	void CListTableElementUI::SetVerticalDisable( UINT len )
	{
		m_uVerticalDisable = len;
	}

	void CListTableElementUI::SetItemTag( UINT uTag )
	{
		 m_uItemTag = uTag;
	}

	UINT CListTableElementUI::GetItemTag()
	{
		return m_uItemTag;
	}

	UINT CListTableElementUI::GetVerticalDisable()
	{
		return m_uVerticalDisable;
	}

}