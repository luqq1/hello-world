#pragma once
using namespace DuiLib;
#define MAX_ACC_COUNT 1025
typedef struct {
	void*        pControl;
	wchar_t*     strName;
	wchar_t*     strTxt;
	wchar_t*     strUserData;
	int          controlType;
	DWORD        controlStatus;
	RECT         rcBorder;
}tagControlData_t;

typedef struct {
	int               countControlData;
	int               indexControlData;
	HWND              hWnd;
	CStdPtrArray      controlPtrs;
	tagControlData_t  controlDatas[MAX_ACC_COUNT];
}tagAccProxy_t;