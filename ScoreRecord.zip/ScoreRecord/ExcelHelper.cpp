#include <Windows.h>
#include <Shlwapi.h>
#include "ExcelHelper.h"
#include "Utils.h"
#include <direct.h>

using namespace libxl;


CExcelHelper::CExcelHelper()
{
	if (!CUtils::IsDirExist(std::wstring(TEXT("�˵�")))) {
		mkdir("�˵�");
	}
	//test();
}


CExcelHelper::~CExcelHelper()
{
}

int CExcelHelper::test()
{
	//xlnt::workbook wb;
	//wb.load("template.xlsx");
	//xlnt::worksheet ws = wb.active_sheet();
	////ws.cell("A1").value(5);
	////ws.cell("B2").value("string data");
	////ws.cell("C3").formula("=RAND()");
	////ws.merge_cells("C3:C4");
	////ws.freeze_panes("B2");
	//ws.cell("E2").value("23");
	//wb.save("out.xlsx");

	Book* book = xlCreateBook();
	if (book)
	{
		book->setKey(L"GCCG", L"windows-282123090cc0e6036db16b60a1o3p0h9");
		if (book->load(L"example1.xls"))
		{
			for (int i = 1; i < 100; i++)
			{
				Sheet* sheet = book->getSheet(i);
				if (sheet)
				{
					sheet->insertCol(4, 4);
					sheet->copyCell(0, 2, 0, 4);
					sheet->copyCell(1, 2, 1, 4);
					sheet->writeStr(0, 4, TEXT("id"));
					sheet->writeStr(1, 4, L"");
					//double d = 1.0;// sheet->readNum(4, 1);
					//sheet->writeNum(2, 1, d * 4);
					//sheet->writeNum(2, 2, d * 2);
					//sheet->writeStr(10, 1, L"new string !");
				}
			}

			if (book->save(L"out.xls"))
			{
				std::cout << "\nFile example.xls has been modified." << std::endl;
				//::ShellExecute(NULL, L"open", L"..\\generate\\example.xls", NULL, NULL, SW_SHOW);
			}
			else
			{
				std::cout << book->errorMessage() << std::endl;
			}
		}
		else
		{
			std::cout << "At first run generate !" << std::endl;
		}

		book->release();
	}
	return 0;
}

bool CExcelHelper::RecordRecharge(const std::string & rid, const std::string & agency, const std::string & userId, const std::string & money, const std::string &gift)
{
	bool bRes = false, bLoad;
	Book* book = xlCreateBook();
	if (book)
	{
		book->setKey(L"GCCG", L"windows-282123090cc0e6036db16b60a1o3p0h9");
		std::wstring wstrFile = TEXT(".\\�˵�\\") + CUtils::UTF8ToUnicode((agency + ".xls").c_str());
		if (CUtils::IsFileExist(wstrFile)) {
			bLoad = book->load(wstrFile.c_str());
			//wstrFile = CUtils::ANSIToUnicode((agency + ".xls").c_str());
		}
		else {
			//bLoad = book->load(L"example.xls");
			bLoad = book->load(L"example.dat");
		}
		if (bLoad) {
			Sheet* sheet = book->getSheet(0);
			if (sheet)
			{
				std::wstring strUserId;
				std::wstring curUserId = CUtils::UTF8ToUnicode(userId.c_str());
				int i, j;
				bool bFind = false;
				for (i = 1; i <= 4; i++) {
					for (j = 1; j <= 25; j++) {
						CellType cellType = sheet->cellType(j, i * 4);
						if (CELLTYPE_STRING == cellType) {
							strUserId = sheet->readStr(j, i * 4);
						}
						else if (CELLTYPE_NUMBER == cellType) {
							strUserId = sheet->readNum(j, i * 4);
						}
						if (CELLTYPE_EMPTY == cellType || CELLTYPE_BLANK == cellType) {
							sheet->writeStr(j, i * 4, curUserId.c_str());
							bFind = true;
							break;
						}
						else if (strUserId == curUserId) {
							bFind = true;
							break;
						}
					}
					if (bFind) {
						break;
					}
				}
				if (!bFind) {
					return bRes;
				}
				int index;
				index = j + 25 * (i - 1);
				Sheet* sheetAgency = book->getSheet(index);
				for (int k = 2; k < 200; k++) {
					CellType cellType = sheetAgency->cellType(k, 1);
					if (CELLTYPE_EMPTY == cellType) {
						std::wstring wstrMoney = CUtils::ANSIToUnicode(money.c_str());
						std::wstring wstrGift = CUtils::ANSIToUnicode(gift.c_str());
						int total = CUtils::WStringToInt(wstrMoney) + CUtils::WStringToInt(wstrGift);
						sheetAgency->writeNum(k, 1, total);
						sheetAgency->writeStr(k, 4, CUtils::UTF8ToUnicode(rid.c_str()).c_str());
						break;
					}
				}
				//std::wstring wstrUserId = CUtils::ANSIToUnicode(userId.c_str());
				sheetAgency->writeStr(0, 0, curUserId.c_str());
			}

			if (book->save(wstrFile.c_str()))
			{
				bRes = true;
				std::cout << "\nFile example.xls has been modified." << std::endl;
			}
			else
			{
				std::cout << book->errorMessage() << std::endl;
				//MessageBoxA(NULL, book->errorMessage(), "", MB_OK);
				MessageBox(NULL, TEXT("�޷�д���˵��ļ��������ļ��Ƿ�򿪣�"), TEXT("����"), MB_OK);
			}
		}
		else
		{
			std::cout << "At first run generate !" << std::endl;
		}

		book->release();
	}
	return bRes;
}

bool CExcelHelper::RollBack(const std::string &uid, const std::string &rid, const std::string &agency)
{
	bool bRes = false, bLoad;
	Book* book = xlCreateBook();
	if (book)
	{
		book->setKey(L"GCCG", L"windows-282123090cc0e6036db16b60a1o3p0h9");
		std::wstring wstrFile = TEXT(".\\�˵�\\") + CUtils::ANSIToUnicode((agency + ".xls").c_str());
		if (CUtils::IsFileExist(wstrFile)) {
			bLoad = book->load(wstrFile.c_str());
			//wstrFile = CUtils::ANSIToUnicode((agency + ".xls").c_str());
		}
		else {
			return false;
		}
		if (bLoad) {
			Sheet* sheet = book->getSheet(0);
			if (sheet)
			{
				std::wstring strUserId;
				std::wstring curUserId = CUtils::UTF8ToUnicode(uid.c_str());
				int i, j;
				bool bFind = false;
				for (i = 1; i <= 4; i++) {
					for (j = 1; j <= 25; j++) {
						CellType cellType = sheet->cellType(j, i * 4);
						if (CELLTYPE_STRING == cellType) {
							strUserId = sheet->readStr(j, i * 4);
						}
						else if (CELLTYPE_NUMBER == cellType) {
							strUserId = sheet->readNum(j, i * 4);
						}
						if (CELLTYPE_EMPTY == cellType || CELLTYPE_BLANK == cellType) {
							//sheet->writeStr(j, i * 4, curUserId.c_str());
							//bFind = true;
							break;
						}
						else if (strUserId == curUserId) {
							bFind = true;
							break;
						}
					}
					if (bFind) {
						break;
					}
				}
				if (!bFind) {
					return bRes;
				}
				int index;
				index = j + 25 * (i - 1);
				std::wstring ridToFind = CUtils::UTF8ToUnicode(rid.c_str());
				Sheet* sheetAgency = book->getSheet(index);
				for (int k = 2; k < 200; k++) {
					CellType cellType = sheetAgency->cellType(k, 4);
					if (CELLTYPE_STRING == cellType && sheetAgency->readStr(k, 4) == ridToFind) {
						sheetAgency->clear(k, k, 1, 4);
						break;
					} else if (CELLTYPE_EMPTY == cellType) {
						break;
					}
				}
				//std::wstring wstrUserId = CUtils::ANSIToUnicode(userId.c_str());
				//sheetAgency->writeStr(0, 0, curUserId.c_str());
			}

			if (book->save(wstrFile.c_str()))
			{
				bRes = true;
				std::cout << "\nFile example.xls has been modified." << std::endl;
			}
			else
			{
				std::cout << book->errorMessage() << std::endl;
				//MessageBoxA(NULL, book->errorMessage(), "", MB_OK);
				MessageBox(NULL, TEXT("�޷�д���˵��ļ��������ļ��Ƿ�򿪣�"), TEXT("����"), MB_OK);
			}
		}
		else
		{
			std::cout << "At first run generate !" << std::endl;
		}

		book->release();
	}
	return bRes;
}
