/**
	author:lqq
	email:qqlu_125@163.com
*/

#include "ScoreRecordMain.h"
#include "resource.h"

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPSTR /*lpCmdLine*/, int nCmdShow)
{
	CPaintManagerUI::SetInstance(hInstance);
	CPaintManagerUI::SetResourcePath(CPaintManagerUI::GetInstancePath() + _T("ui"));
	//CPaintManagerUI::SetResourceZip(_T("ScoreRecordRes.zip"));

	CScoreRecordMain *pMainFrame = new CScoreRecordMain();
	if (pMainFrame == NULL) {
		return 0;
	}
	pMainFrame->Create(NULL, _T("�Ƿ�����"), UI_WNDSTYLE_FRAME, WS_EX_STATICEDGE | WS_EX_APPWINDOW, 0, 0, 600, 320);
	//pMainFrame->Create(NULL, _T("ScoreRecord"), UI_WNDSTYLE_FRAME, WS_EX_STATICEDGE | WS_EX_APPWINDOW, 0, 0, 600, 320);
	pMainFrame->CenterWindow();
	pMainFrame->ShowWindow(true);
	pMainFrame->SetIcon(IDI_ICON1);

	CPaintManagerUI::MessageLoop();

	return 0;
}
