#include "JsonParser.h"
#include "..\include\rapidjson\document.h"
#include "Utils.h"

CJsonParser::CJsonParser()
{
}


CJsonParser::~CJsonParser()
{
}

bool CJsonParser::ParseResult(const std::string &str)
{
	return false;
}

bool CJsonParser::ParseRecent10(const std::string & response, std::vector<RecentRecordData>& records)
{
	rapidjson::Document recentDoc;
	recentDoc.Parse(response.c_str());
	records.clear();
	if (recentDoc.HasMember("data")) {
		rapidjson::Value data;
		data = recentDoc["data"];
		if (data.IsArray() && !data.Empty()) {
			rapidjson::Value recordVal;
			for (rapidjson::SizeType i = 0; i < data.Size(); i++) {
				recordVal = data[i];
				if (recordVal.IsObject()) {
					RecentRecordData record;
					record.recordId = CUtils::IntToWString(recordVal["id"].GetInt());
					record.uid = CUtils::IntToWString(recordVal["uid"].GetInt());
					record.agency = CUtils::UTF8ToUnicode(recordVal["agencyinfo"].GetString());
					record.nick = CUtils::UTF8ToUnicode(recordVal["nickname"].GetString());
					record.money = CUtils::UTF8ToUnicode(recordVal["money"].GetString());
					record.gift = CUtils::UTF8ToUnicode(recordVal["gift"].GetString());
					record.balance = CUtils::UTF8ToUnicode(recordVal["balance"].GetString());
					record.time = CUtils::UTF8ToUnicode(recordVal["updated_at"].GetString());

					records.push_back(record);
				}
			}
		}
		return true;
	}
	return false;
}
