#pragma once
#include <string>

class CUtils
{
public:
	CUtils();
	~CUtils();

	static std::string UnicodeToANSI(const wchar_t *pstr);
	static std::wstring ANSIToUnicode(const char *pstr);
	static std::wstring UTF8ToUnicode(const char *pstr);
	static std::string UnicodeToUTF8(const wchar_t *pstr);
	static bool IsFileExist(const std::wstring &csFile);
	static bool IsDirExist(const std::wstring &wsDir);
	static std::wstring IntToWString(int n);
	static int WStringToInt(const std::wstring &wstr);
};

