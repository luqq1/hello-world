#pragma once
#include <windows.h>
#include <string>

class CHttpBase
{
public:
	CHttpBase();
	~CHttpBase();

	virtual BOOL HttpPost(std::string url, std::string post, std::string& response, bool& bStopRequest, UINT& uRetCode, UINT timeout = 10, bool bhead = false);

	virtual BOOL HttpGet(std::string url, std::string& response, bool& bStopRequest, UINT& uRetCode, UINT timeout = 15, bool bhead = false);

	void SetBaseUrl(std::string strUrl);
	void SetRequest(std::string strResquest);
	void SetCookie(std::string strCookie);

	virtual bool  CheckReturnValueByCode(UINT uRetCode);
protected:
	std::string m_strBaseUrl;
	std::string m_strRequest;
	std::string m_strCookie;
	int         m_connectTimeout;
	static size_t OnWriteData(void* buffer, size_t size, size_t nmemb, void* lpVoid);
	static size_t OnRequestProcess(void *progress_data, double t, double d, double ultotal, double ulnow);

	BOOL HttpPostBase(struct curl_slist *chunk, std::string strUrl, std::string post, std::string& response, bool& bStopRequest, UINT& uRetCode, UINT timeout = 10, bool bhead = false);
	BOOL HttpGetBase(struct curl_slist *chunk, std::string strUrl, std::string& response, bool& bStopRequest, UINT& uRetCode, UINT timeout = 15, bool bhead = false);

private:
	struct curl_slist *Prepare();
};

