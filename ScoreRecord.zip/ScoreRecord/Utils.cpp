#include "stdafx.h"
#include "Utils.h"



CUtils::CUtils()
{
}


CUtils::~CUtils()
{
}

std::string CUtils::UnicodeToANSI(const wchar_t *pstr)
{
	char *pElementText;
	int    iTextLen;
	if (!pstr) {
		return "";
	}
	// wide char to multi char
	iTextLen = WideCharToMultiByte(CP_ACP, 0, pstr, -1, NULL, 0, NULL, NULL);
	pElementText = new char[iTextLen + 1];
	memset((void*)pElementText, 0, sizeof(char) * (iTextLen + 1));
	::WideCharToMultiByte(CP_ACP, 0, pstr, -1, pElementText, iTextLen, NULL, NULL);
	std::string strText;
	strText = pElementText;
	delete[] pElementText;
	return strText;
}

std::wstring CUtils::ANSIToUnicode(const char * pstr)
{
	std::wstring  rt;
	int  len = 0;
	if (!pstr) {
		return rt;
	}
	len = strlen(pstr);
	int  unicodeLen = ::MultiByteToWideChar(CP_ACP, 0, pstr, -1, NULL, 0);
	wchar_t *  pUnicode;
	pUnicode = new  wchar_t[unicodeLen + 1];
	memset(pUnicode, 0, (unicodeLen + 1) * sizeof(wchar_t));
	::MultiByteToWideChar(CP_ACP, 0, pstr, -1, (LPWSTR)pUnicode, unicodeLen);
	rt = (wchar_t*)pUnicode;
	delete  pUnicode;

	return  rt;
}

std::wstring CUtils::UTF8ToUnicode(const char * pstr)
{
	std::wstring  rt;
	int  len = 0;
	if (!pstr) {
		return rt;
	}
	len = strlen(pstr);
	int  unicodeLen = ::MultiByteToWideChar(CP_UTF8, 0, pstr, -1, NULL, 0);
	wchar_t *  pUnicode;
	pUnicode = new  wchar_t[unicodeLen + 1];
	memset(pUnicode, 0, (unicodeLen + 1) * sizeof(wchar_t));
	::MultiByteToWideChar(CP_UTF8, 0, pstr, -1, (LPWSTR)pUnicode, unicodeLen);
	rt = (wchar_t*)pUnicode;
	delete  pUnicode;

	return  rt;
}

std::string CUtils::UnicodeToUTF8(const wchar_t * pstr)
{
	char* pElementText;
	int    iTextLen;
	if (!pstr) {
		return std::string();
	}
	// wide char to multi char
	iTextLen = WideCharToMultiByte(CP_UTF8, 0, pstr, -1, NULL, 0, NULL, NULL);
	pElementText = new char[iTextLen + 1];
	memset((void*)pElementText, 0, sizeof(char) * (iTextLen + 1));
	::WideCharToMultiByte(CP_UTF8, 0, pstr, -1, pElementText, iTextLen, NULL, NULL);
	std::string strText;
	strText = pElementText;
	delete[] pElementText;
	return strText;
}

bool CUtils::IsFileExist(const std::wstring & csFile)
{
	DWORD dwAttrib = GetFileAttributes(csFile.c_str());
	return INVALID_FILE_ATTRIBUTES != dwAttrib && 0 == (dwAttrib & FILE_ATTRIBUTE_DIRECTORY);
}

bool CUtils::IsDirExist(const std::wstring &wsDir)
{
	DWORD dwAttrib = GetFileAttributes(wsDir.c_str());
	return INVALID_FILE_ATTRIBUTES != dwAttrib && (dwAttrib & FILE_ATTRIBUTE_DIRECTORY);
}

std::wstring CUtils::IntToWString(int n)
{
	wchar_t buf[100] = {0};
	_itow_s(n, buf, 10);
	return std::wstring(buf);
}

int CUtils::WStringToInt(const std::wstring &wstr)
{
	return std::stoi(wstr, nullptr, 10);
}
