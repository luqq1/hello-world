#pragma once
#include <string>
#include <vector>
#include "ScoreRecordDef.h"

class CJsonParser
{
public:
	CJsonParser();
	~CJsonParser();
	bool ParseResult(const std::string &str);
	bool ParseRecent10(const std::string &response, std::vector<RecentRecordData> &records);
};

