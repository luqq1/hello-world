#include "ScoreRecordMain.h"
#include "Utils.h"
#include "rapidjson\document.h"
#include "JsonParser.h"
#include <ShellAPI.h>

#define TIMER_RECENT_INTERVAL 60000


CScoreRecordMain::CScoreRecordMain()
{
}


CScoreRecordMain::~CScoreRecordMain()
{
}

void CScoreRecordMain::Init()
{
	m_pWorker = CRechargeWorker::GetInstance();
	m_pWorker->SetMainWnd(m_hWnd);
	m_pWorker->GetRecentRecharge(&m_recordList);
	SetTimer(m_hWnd, IDT_TIMER_RECENT, TIMER_RECENT_INTERVAL, (TIMERPROC)NULL);
}

void CScoreRecordMain::OnPrepare(TNotifyUI & msg)
{
	m_pAccountEdit = static_cast< CTipEditUI *>(m_pm.FindControl(_T("Edit_Account")));
	m_pMoneyEdit = static_cast< CTipEditUI *>(m_pm.FindControl(_T("Edit_Money")));
	m_pGiftEdit = static_cast< CTipEditUI *>(m_pm.FindControl(_T("Edit_Gift")));
	m_pStatusLabel = static_cast< CLabelUI *>(m_pm.FindControl(_T("LabelStatus")));
	m_pTitleLabel = static_cast< CLabelUI *>(m_pm.FindControl(_T("LabelTitle")));
	m_pRechargeBtn = static_cast< CButtonUI *>(m_pm.FindControl(_T("ButtonCommit")));
}

LPCTSTR CScoreRecordMain::GetItemText(CControlUI * pControl, int iIndex, int iSubItem)
{
	TCHAR szBuf[MAX_PATH] = { 0 };
	switch (iSubItem) {
	case 0:
		_stprintf(szBuf, _T("%s"), _T("��"));
		break;
	}
	pControl->SetUserData(szBuf);
	return pControl->GetUserData();
}

void CScoreRecordMain::Notify(TNotifyUI & msg)
{
	if (msg.sType == _T("windowinit")) {
		OnPrepare(msg);
	}
	else if (msg.sType == _T("click")) {
		if (msg.pSender->GetName() == _T("ButtonCancel")) {
			ResetEdit();
		}
		else if (msg.pSender->GetName() == _T("ButtonCommit")) {
			//MessageBox(NULL, _T("�ύ"), _T(""), MB_OK);
			std::wstring strAccount = m_pAccountEdit->GetText();
			std::wstring strMoney = m_pMoneyEdit->GetText();
			std::wstring strGift = m_pGiftEdit->GetText();
			int money = _ttoi(strMoney.c_str());
			int gift = _ttoi(strGift.c_str());
			if (money <= 0 || gift < 0) {
				MessageBox(NULL, _T("������"), _T("��ʾ"), MB_OK);
				return;
			}
			ShowProgress(_T("���ڳ�ֵ..."));
			m_pWorker->Recharge(strAccount, strMoney, strGift);
		}
		else if (msg.pSender->GetName() == _T("ButtonRollback")) {
			CListContainerElementUI * pElement = (CListContainerElementUI *)msg.pSender->GetParent()->GetParent()->GetParent();
			int tag = pElement->GetTag();
			RecentRecordData &record = m_recordList[tag];
			//std::string response;
			//std::string id = CUtils::UnicodeToANSI(record.recordId.c_str());
			std::wstring strInfo = _T("�Ƿ񳷻ظó�ֵ���û�id��") + record.uid + _T("����") + record.money + _T("�����֣�") + record.gift + _T("��");
			int boxId = MessageBox(NULL, strInfo.c_str(), _T("��ʾ"), MB_OKCANCEL);
			if (boxId == IDOK) {
				ShowProgress(_T("���ڳ���..."));
				m_pWorker->RollBack(record.recordId, record.uid, record.agency, record.money, record.gift);
			}
		}
		else if (msg.pSender->GetName() == _T("ButtonOpenRecord")) {
			TCHAR szDir[MAX_PATH + 1] = { 0 };
			HINSTANCE ret;
			DWORD dwRet = GetCurrentDirectory(MAX_PATH, szDir);
			if (dwRet > 0)
			{
				_tcscat(szDir, _T("\\�˵�"));
				ret = ShellExecute(NULL, _T("open"), NULL, NULL, szDir, SW_SHOWNORMAL);
			}
		}
	}
}

LRESULT CScoreRecordMain::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lRes = 0;
	BOOL bHandled = TRUE;
	switch (uMsg)
	{
	case WM_CREATE:
		lRes = OnCreate(uMsg, wParam, lParam, bHandled);
		break;
	case WM_CLOSE:
		lRes = OnClose(uMsg, wParam, lParam, bHandled);
		break;
	case WM_DESTROY:
		lRes = OnDestroy(uMsg, wParam, lParam, bHandled);
		break;
	case WM_NCACTIVATE:
		lRes = OnNcActivate(uMsg, wParam, lParam, bHandled);
		break;
	case WM_SIZE:
		lRes = OnSize(uMsg, wParam, lParam, bHandled);
		break;
	case WM_RECHARGE:
	case WM_ROLLBACK:
	{
		bool bRet = wParam;
		std::wstring strAction = (uMsg == WM_RECHARGE) ? _T("��ֵ") : _T("����");
		std::wstring *pMsg = (std::wstring *)lParam;
		if (pMsg) {
			if (bRet) {
				strAction += _T("�ɹ���");
				ResetEdit();
			}
			else {
				strAction += _T("ʧ�ܣ�");
			}
			m_pTitleLabel->SetText(strAction.c_str());
			m_pStatusLabel->SetText((*pMsg).c_str());
			delete pMsg;
		}
		ShowProgress(_T(""), false);
		m_pWorker->GetRecentRecharge(&m_recordList);
	}
	case WM_RECENT:
	{
		bool bRet = wParam;
		if (bRet) {
			CListUI* pList = static_cast<CListUI*>(m_pm.FindControl(_T("rechargeList")));
			if (pList) {
				pList->RemoveAll();
				int i = 0;
				for (auto it = m_recordList.begin(); it != m_recordList.end(); it++) {
					CDialogBuilder builder;
					CListContainerElementUI *pItem = (CListContainerElementUI *)(builder.Create(_T("RecentItem.xml"), (UINT)0, NULL, &m_pm, NULL));
					pItem->SetTag(i++);
					setItemData(pItem, *it);
					pList->Add(pItem);
				}
			}
		}
	}
	break;
	case WM_TIMER:
	{
		switch (wParam)
		{
		case IDT_TIMER_RECENT:
		{
			m_pWorker->GetRecentRecharge(&m_recordList);
			//SetTimer(m_hWnd, IDT_TIMER_RECENT, TIMER_RECENT_INTERVAL, (TIMERPROC)NULL);
		}
		break;
		default:
			break;
		}
	}
	break;
	default:
		bHandled = FALSE;
		break;
	}
	if (bHandled) return lRes;
	if (m_pm.MessageHandler(uMsg, wParam, lParam, lRes)) return lRes;
	return CWindowWnd::HandleMessage(uMsg, wParam, lParam);
}

LRESULT CScoreRecordMain::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bHandled)
{
	LONG styleValue = ::GetWindowLong(*this, GWL_STYLE);
	//styleValue &= ~WS_CAPTION;
	::SetWindowLong(*this, GWL_STYLE, styleValue | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);
	m_pm.Init(m_hWnd);
	//m_pm.SetTransparent(100);
	CDialogBuilder builder;
	CControlUI* pRoot = builder.Create(_T("MainWnd.xml"), (UINT)0, NULL, &m_pm);
	ASSERT(pRoot && "Failed to parse XML");
	m_pm.AttachDialog(pRoot);
	m_pm.AddNotifier(this);
	Init();
	return 0;
}

LRESULT CScoreRecordMain::OnClose(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bHandled)
{
	bHandled = FALSE;
	KillTimer(m_hWnd, IDT_TIMER_RECENT);
	return 0;
}

LRESULT CScoreRecordMain::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bHandled)
{
	::PostQuitMessage(0L);
	bHandled = FALSE;
	return 0;
}

LRESULT CScoreRecordMain::OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL & bHandled)
{
	if (::IsIconic(*this)) bHandled = FALSE;
	return (wParam == 0) ? TRUE : FALSE;
}

LRESULT CScoreRecordMain::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CControlUI *pHlMainWndWait = m_pm.FindControl(_T("Hl_MainWnd_Wait"));

	if (pHlMainWndWait) {
		RECT rc;
		GetWindowRect(m_pm.GetPaintWindow(), &rc);
		RECT tRC = { 0, 0, rc.right - rc.left, rc.bottom - rc.top };
		pHlMainWndWait->SetPos(tRC);
	}
	bHandled = false;
	return 0;
}

void CScoreRecordMain::ShowProgress(LPCTSTR text, bool bShow)
{
	CControlUI *pHlMainWndWait = m_pm.FindControl(_T("Hl_MainWnd_Wait"));

	if (bShow) {
		RECT rc;
		GetWindowRect(m_pm.GetPaintWindow(), &rc);
		RECT tRC = { 0, 0, rc.right - rc.left, rc.bottom - rc.top };
		pHlMainWndWait->SetPos(tRC);
		pHlMainWndWait->SetVisible(true);
		CLabelUI *CoverText = static_cast<CLabelUI *>(m_pm.FindControl(_T("Lab_Cover_tip")));
		if (CoverText) {
			CoverText->SetText(text);
		}
	}
	else {
		pHlMainWndWait->SetVisible(false);
	}
}

void CScoreRecordMain::ResetEdit()
{
	//m_pAccountEdit->SetText(_T("123"));
	//m_pMoneyEdit->SetText(_T("1"));
	//m_pGiftEdit->SetText(_T("0"));
	m_pAccountEdit->SetText(_T(""));
	m_pMoneyEdit->SetText(_T(""));
	m_pGiftEdit->SetText(_T("0"));
}

void CScoreRecordMain::setItemData(CListContainerElementUI * pElement, const RecentRecordData & record)
{
	CLabelUI *pAgency = (CLabelUI *)pElement->FindSubControl(_T("agency"));
	if (pAgency)
		pAgency->SetText(record.agency.c_str());
	CLabelUI *pUserId = (CLabelUI *)pElement->FindSubControl(_T("userid"));
	if (pUserId)
		pUserId->SetText(record.recordId.c_str());
	CLabelUI *pNick = (CLabelUI *)pElement->FindSubControl(_T("nick"));
	if (pNick)
		pNick->SetText(record.nick.c_str());
	CLabelUI *pMoney = (CLabelUI *)pElement->FindSubControl(_T("money"));
	if (pMoney)
		pMoney->SetText(record.money.c_str());
	CLabelUI *pGift = (CLabelUI *)pElement->FindSubControl(_T("gift"));
	if (pGift)
		pGift->SetText(record.gift.c_str());
	CLabelUI *pBalance = (CLabelUI *)pElement->FindSubControl(_T("balance"));
	if (pBalance)
		pBalance->SetText(record.balance.c_str());
	CLabelUI *pTime = (CLabelUI *)pElement->FindSubControl(_T("time"));
	if (pTime)
		pTime->SetText(record.time.c_str());
}
