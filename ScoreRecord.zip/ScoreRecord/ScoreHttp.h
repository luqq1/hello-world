#pragma once
#include <string>
#include "HttpBase.h"

class CScoreHttp
{
public:
	CScoreHttp();
	~CScoreHttp();
	bool Recharge(const std::string &userId, const std::string &money, const std::string &gift, std::string &response);
	bool Recharge(const std::wstring &userId, const std::wstring &money, const std::wstring &gift, std::string &response);
	bool getRecent10Record(std::string &response);
	bool rollBack(const std::string &id, std::string &response);

private:
	CHttpBase m_Http;
};

