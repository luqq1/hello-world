#include "HttpBase.h"
#include "curl/curl.h"
#include <sstream>


CHttpBase::CHttpBase()
{
}


CHttpBase::~CHttpBase()
{
}

BOOL CHttpBase::HttpPost(std::string url, std::string post, std::string & response, bool & bStopRequest, UINT & uRetCode, UINT timeout, bool bhead)
{
	std::string strUrl;
	struct curl_slist *chunk = Prepare();

	strUrl = m_strBaseUrl + url;
	return HttpPostBase(chunk, strUrl, post, response, bStopRequest, uRetCode, timeout, bhead);
}

BOOL CHttpBase::HttpGet(std::string url, std::string & response, bool & bStopRequest, UINT & uRetCode, UINT timeout, bool bhead)
{
	std::string strUrl;
	struct curl_slist *chunk = Prepare();

	chunk = curl_slist_append(chunk, "Content-Type: application/x-www-form-urlencoded");
	chunk = curl_slist_append(chunk, "User-Agent: owncloudClient");
	strUrl = m_strBaseUrl + url;
	return HttpGetBase(chunk, strUrl, response, bStopRequest, uRetCode, timeout, bhead);
}

BOOL CHttpBase::HttpPostBase(curl_slist * chunk, std::string strUrl, std::string post, std::string & response, bool & bStopRequest, UINT & uRetCode, UINT timeout, bool bhead)
{
	CURLcode res;
	CURL* m_curl = curl_easy_init();
	if (m_curl == NULL) {
		curl_slist_free_all(chunk);
		return FALSE;
	}
	std::stringstream ss;
	ss << "Content-Length:" << post.size();
	std::string cstrContexLen = ss.str();
	chunk = curl_slist_append(chunk, "Accept-Language: zh-CN");
	chunk = curl_slist_append(chunk, "Accept-Encoding: gzip, deflate");
	chunk = curl_slist_append(chunk, "Connection:keep-alive");
	chunk = curl_slist_append(chunk, "Connection: Keep-Alive");
	chunk = curl_slist_append(chunk, "x-requested-with: XMLHttpRequest");
	chunk = curl_slist_append(chunk, cstrContexLen.c_str());
	chunk = curl_slist_append(chunk, "Cache-Control: no-cache");
	curl_easy_setopt(m_curl, CURLOPT_HTTPHEADER, chunk);
	curl_easy_setopt(m_curl, CURLOPT_URL, strUrl.c_str());
	curl_easy_setopt(m_curl, CURLOPT_POST, 1);
	curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, post.c_str());
	curl_easy_setopt(m_curl, CURLOPT_READFUNCTION, NULL);
	curl_easy_setopt(m_curl, CURLOPT_ENCODING, "gzip");
	if (bhead) {
		//����ͷ����Ϣ
		curl_easy_setopt(m_curl, CURLOPT_HEADER, 1);
	}
	curl_easy_setopt(m_curl, CURLOPT_WRITEFUNCTION, OnWriteData);
	curl_easy_setopt(m_curl, CURLOPT_WRITEDATA, (void *)&response);
	curl_easy_setopt(m_curl, CURLOPT_PROGRESSFUNCTION, OnRequestProcess);
	curl_easy_setopt(m_curl, CURLOPT_PROGRESSDATA, &bStopRequest);
	curl_easy_setopt(m_curl, CURLOPT_NOPROGRESS, FALSE);
	curl_easy_setopt(m_curl, CURLOPT_NOSIGNAL, 1);
	curl_easy_setopt(m_curl, CURLOPT_CONNECTTIMEOUT, m_connectTimeout);
	curl_easy_setopt(m_curl, CURLOPT_TIMEOUT, timeout);
	res = curl_easy_perform(m_curl);
	long retcode = 0;
	curl_easy_getinfo(m_curl, CURLINFO_RESPONSE_CODE, &retcode);
	curl_slist_free_all(chunk);
	curl_easy_cleanup(m_curl);
	uRetCode = (res << 16) | retcode;
	if (!CheckReturnValueByCode(uRetCode)) {
		return FALSE;
	}
	return res == CURLE_OK;
}

BOOL CHttpBase::HttpGetBase(curl_slist * chunk, std::string strUrl, std::string & response, bool & bStopRequest, UINT & uRetCode, UINT timeout, bool bhead)
{
	CURL *curl;
	CURLcode code;
	std::string szbuffer;
	std::string szheader_buffer;
	//char errorBuffer[CURL_ERROR_SIZE];

	std::string useragent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0.1";

	curl_global_init(CURL_GLOBAL_ALL);
	curl = curl_easy_init();
	if (curl) {
		// Զ��URL��֧�� http, https, ftp
		curl_easy_setopt(curl, CURLOPT_URL, strUrl.c_str());
		curl_easy_setopt(curl, CURLOPT_USERAGENT, useragent.c_str());
		// �ٷ����ص�DLL����֧��GZIP��Accept-Encoding:deflate, gzip
		curl_easy_setopt(curl, CURLOPT_ENCODING, "gzip, deflate");
		//curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);//������Ϣ��
		//����������SSL��֤����ʹ��CA֤��
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
		//���������SSL��֤�����ָ��һ��CA֤��Ŀ¼
		//curl_easy_setopt(curl, CURLOPT_CAPATH, "this is ca ceat");
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

		curl_easy_setopt(curl, CURLOPT_MAXREDIRS, 5);
		//����301��302��ת����location
		curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
		//ץȡ���ݺ󣬻ص�����
		//ץȡ���ݺ󣬻ص�����
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, OnWriteData);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
		//ץȡͷ��Ϣ���ص�����
		curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, OnWriteData);
		curl_easy_setopt(curl, CURLOPT_HEADERDATA, &szheader_buffer);
		curl_easy_setopt(curl, CURLOPT_PROGRESSFUNCTION, OnRequestProcess);
		curl_easy_setopt(curl, CURLOPT_PROGRESSDATA, &bStopRequest);
		curl_easy_setopt(curl, CURLOPT_NOPROGRESS, FALSE);

		code = curl_easy_perform(curl);
		long retcode = 0;
		curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &retcode);
		curl_easy_cleanup(curl);
		curl_global_cleanup();
		uRetCode = (code << 16) | retcode;
		if (!CheckReturnValueByCode(uRetCode)) {
			return FALSE;
		}
		return code == CURLE_OK;
	}
	curl_global_cleanup();
	return FALSE;
}

curl_slist * CHttpBase::Prepare()
{
	struct curl_slist *chunk = NULL;

	chunk = curl_slist_append(chunk, "Accept: */*");
	if (!m_strRequest.empty()) {
		std::string requesttoken = "requesttoken: " + m_strRequest;
		chunk = curl_slist_append(chunk, requesttoken.c_str());
	}
	if (!m_strCookie.empty()) {
		std::string cookie = "Cookie:" + m_strCookie;
		chunk = curl_slist_append(chunk, cookie.c_str());
	}
	return chunk;
}

void CHttpBase::SetBaseUrl(std::string strUrl)
{
	m_strBaseUrl = strUrl;
}

void CHttpBase::SetRequest(std::string strResquest)
{
	m_strRequest = strResquest;
}

void CHttpBase::SetCookie(std::string strCookie)
{
	m_strCookie = strCookie;
}

bool CHttpBase::CheckReturnValueByCode(UINT uRetCode)
{
	return true;
}

size_t CHttpBase::OnWriteData(void * buffer, size_t size, size_t nmemb, void * lpVoid)
{
	std::string* str = dynamic_cast<std::string*>((std::string *)lpVoid);
	if (NULL == str || NULL == buffer) {
		return -1;
	}
	char* pData = (char*)buffer;
	str->append(pData, size * nmemb);
	return size * nmemb;
}

size_t CHttpBase::OnRequestProcess(void * progress_data, double t, double d, double ultotal, double ulnow)
{
	bool *bStopRequest = (bool*)progress_data;
	if (bStopRequest) {
		if (*bStopRequest) {
			//TRACE(_T("Stop Http Requests\n"));
			return -1;
		}
	}
	return 0;
}
