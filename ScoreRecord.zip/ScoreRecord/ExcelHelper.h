#pragma once

//#include <xlnt/xlnt.hpp>
#include <string>
#include <iostream>
#include "libxl.h"
#include "rapidjson\document.h"

class CExcelHelper
{
public:
	CExcelHelper();
	~CExcelHelper();

	int test();
	bool RecordRecharge(const std::string &rid, const std::string &agency, const std::string &userId, const std::string &money, const std::string &gift);
	bool RollBack(const std::string &uid, const std::string &rid, const std::string &agency);
};

