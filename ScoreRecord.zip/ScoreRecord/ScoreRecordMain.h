#pragma once
#define WIN32_LEAN_AND_MEAN	
#define _CRT_SECURE_NO_DEPRECATE

#include <windows.h>
#include <objbase.h>

#include "..\DuiLib\UIlib.h"
#include "ScoreHttp.h"
#include "JsonParser.h"
#include "ExcelHelper.h"
#include "RechargeWorker.h"

using namespace DuiLib;

class CScoreRecordMain : public CWindowWnd, public INotifyUI, public IListCallbackUI
{
public:
	CScoreRecordMain();
	~CScoreRecordMain();
	LPCTSTR GetWindowClassName() const {
		return _T("ScoreRecordMain");
	};

	void OnFinalMessage(HWND /*hWnd*/) {
		delete this;
	};
	void Init();
	void OnPrepare(TNotifyUI& msg);
	virtual LPCTSTR GetItemText(CControlUI* pControl, int iIndex, int iSubItem);
	void Notify(TNotifyUI& msg);
	LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnClose(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	void ShowProgress(LPCTSTR text, bool bShow = true);

public:
	CPaintManagerUI m_pm;
private:
	CControlUI *m_pCancelBtn;
	CControlUI *m_pSubmitBtn;
	//CHttpBase m_Http;
	CTipEditUI *m_pAccountEdit;
	CTipEditUI *m_pMoneyEdit;
	CTipEditUI *m_pGiftEdit;
	CLabelUI *m_pStatusLabel;
	CLabelUI *m_pTitleLabel;
	CButtonUI *m_pRechargeBtn;

	CRechargeWorker *m_pWorker;
	//CScoreHttp m_scoreHttp;
	//CJsonParser m_parser;
	std::vector<RecentRecordData> m_recordList;
	//CExcelHelper m_excelHelper;

	void ResetEdit();
	void setItemData(CListContainerElementUI *pElement, const RecentRecordData &record);
};

