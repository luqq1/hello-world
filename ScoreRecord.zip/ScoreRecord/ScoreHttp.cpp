#include "stdafx.h"
#include "ScoreHttp.h"
#include "rapidjson\document.h"
#include "Utils.h"

using namespace rapidjson;

CScoreHttp::CScoreHttp()
{
	m_Http.SetBaseUrl("http://xf28.vip/exsys/");
}


CScoreHttp::~CScoreHttp()
{
}

bool CScoreHttp::Recharge(const std::string &userId, const std::string &money, const std::string &gift, std::string &response)
{
	std::string strPost;
	bool bStop = false;
	UINT uRetCode;
	strPost = "userid=" + userId + "&money=" + money + "&gift=" + gift;
	if (m_Http.HttpPost("labour_recharge", strPost, response, bStop, uRetCode)) {
		return true;
	}
	return false;
}

bool CScoreHttp::Recharge(const std::wstring & userId, const std::wstring & money, const std::wstring & gift, std::string &response)
{
	std::wstring wstrPost;
	bool bStop = false;
	UINT uRetCode;
	wstrPost = TEXT("userid=") + userId + TEXT("&money=") + money + TEXT("&gift=") + gift;
	std::string strPost = CUtils::UnicodeToANSI(wstrPost.c_str());
	if (m_Http.HttpPost("labour_recharge", strPost, response, bStop, uRetCode)) {
		return true;
	}
	return false;
}

bool CScoreHttp::getRecent10Record(std::string & response)
{
	bool bStop = false;
	UINT uRetCode;
	if (m_Http.HttpGet("recharge_10record", response, bStop, uRetCode)) {
		return true;
	}
	return false;
}

bool CScoreHttp::rollBack(const std::string & id, std::string & response)
{
	bool bStop = false;
	UINT uRetCode;
	std::string url = "recharge_rollback?rid=" + id;
	if (m_Http.HttpGet(url, response, bStop, uRetCode)) {
		return true;
	}
	return false;
}
