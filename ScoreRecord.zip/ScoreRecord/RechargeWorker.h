#pragma once
#include <windows.h>
#include "ScoreRecordDef.h"
#include <list>
#include "ScoreHttp.h"
#include "ExcelHelper.h"
#include "JsonParser.h"

class CRechargeWorker
{
protected:
	CRechargeWorker();
	~CRechargeWorker();

public:
	static CRechargeWorker *GetInstance();
	void SetMainWnd(HWND hWnd);
	void AddWork(RechargeAction &action);
	void Recharge(const std::wstring &uid, const std::wstring &money, const std::wstring &gift);
	void RollBack(const std::wstring &recordId, const std::wstring &uid, const std::wstring &agency, const std::wstring &money, const std::wstring &gift);
	void GetRecentRecharge(std::vector<RecentRecordData> *pRecordList);
	bool GetWork(RechargeAction &action);
	void NotifyMainWnd(UINT msg, WPARAM wParam, LPARAM lParam);

	static DWORD WINAPI RechargeThread(void *param);

private:
	CRITICAL_SECTION m_cs;
	HANDLE m_hSemaphore;
	HANDLE m_hThread;
	bool m_bExit;
	HWND m_hWnd;
	std::list<RechargeAction> m_actionList;
	CExcelHelper m_excelHelper;

	CScoreHttp m_scoreHttp;
	CJsonParser m_parser;

	static CRechargeWorker *m_pInstance;
};

