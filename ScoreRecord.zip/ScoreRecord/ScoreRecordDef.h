#pragma once
#include <string>
#include <vector>

#define WM_RECHARGE (WM_USER + 100)
#define WM_RECENT (WM_USER + 101)
#define WM_ROLLBACK (WM_USER + 102)

#define IDT_TIMER_RECENT 1

enum ActionType
{
	ACTION_RECHARGE,
	ACTION_ROLLBACK,
	ACTION_GET_RECENT,
};

struct RecentRecordData {
	std::wstring  recordId;
	std::wstring  uid;
	std::wstring  agency;
	std::wstring  nick;
	std::wstring  money;
	std::wstring  gift;
	std::wstring  balance;
	std::wstring  time;
};

struct RechargeAction {
	ActionType type;
	std::string uid;
	std::string recordId;
	std::string money;
	std::string gift;
	std::vector<RecentRecordData> *pRecordList;
	std::string agency;
};
