#include <tchar.h>
#include "RechargeWorker.h"
#include "rapidjson\document.h"
#include "JsonParser.h"
#include "Utils.h"

const int MAX_SEMAPHORE_COUNT = 10;

CRechargeWorker * CRechargeWorker::m_pInstance = NULL;

CRechargeWorker::CRechargeWorker() :m_bExit(false), m_hSemaphore(NULL)
{
	DWORD dwThreadId;
	if (!InitializeCriticalSectionAndSpinCount(&m_cs, 0x00000400)) {
		//MessageBox(NULL, _T("init critical section fail."), _T("��ʾ"), MB_OK);
		exit(0);
	}
	m_hSemaphore = CreateSemaphore(NULL, 0, MAX_SEMAPHORE_COUNT, NULL);
	if (!m_hSemaphore) {
		exit(0);
	}
	m_hThread = (HANDLE)CreateThread(NULL, 0, RechargeThread, this, 0, &dwThreadId);
	if (!m_hThread) {
		//MessageBox(NULL, _T("�����߳�ʧ��"), _T("��ʾ"), MB_OK);
		exit(0);
	}
}


CRechargeWorker::~CRechargeWorker()
{
	m_bExit = true;
	WaitForSingleObject(m_hThread, 1000);
	CloseHandle(m_hThread);
	CloseHandle(m_hSemaphore);
}

CRechargeWorker * CRechargeWorker::GetInstance()
{
	if (!m_pInstance) {
		m_pInstance = new CRechargeWorker();
	}
	return m_pInstance;
}

void CRechargeWorker::SetMainWnd(HWND hWnd)
{
	m_hWnd = hWnd;
}

void CRechargeWorker::AddWork(RechargeAction &action)
{
	LONG previousCount;
	EnterCriticalSection(&m_cs);
	m_actionList.push_back(action);
	LeaveCriticalSection(&m_cs);
	ReleaseSemaphore(m_hSemaphore, 1, &previousCount);
}

void CRechargeWorker::Recharge(const std::wstring &uid, const std::wstring &money, const std::wstring &gift)
{
	RechargeAction action;
	action.type = ACTION_RECHARGE;
	action.uid = CUtils::UnicodeToANSI(uid.c_str());
	action.money = CUtils::UnicodeToANSI(money.c_str());
	action.gift = CUtils::UnicodeToANSI(gift.c_str());
	AddWork(action);
}

void CRechargeWorker::RollBack(const std::wstring &recordId, const std::wstring &uid, const std::wstring &agency, const std::wstring &money, const std::wstring &gift)
{
	RechargeAction action;
	action.type = ACTION_ROLLBACK;
	action.uid = CUtils::UnicodeToANSI(uid.c_str());
	action.recordId = CUtils::UnicodeToANSI(recordId.c_str());
	action.money = CUtils::UnicodeToANSI(money.c_str());
	action.gift = CUtils::UnicodeToANSI(gift.c_str());
	action.agency = CUtils::UnicodeToANSI(agency.c_str());
	AddWork(action);
}

void CRechargeWorker::GetRecentRecharge(std::vector<RecentRecordData> *pRecordList)
{
	RechargeAction action;
	action.type = ACTION_GET_RECENT;
	action.pRecordList = pRecordList;
	AddWork(action);
}

bool CRechargeWorker::GetWork(RechargeAction &action)
{
	bool bRet = false;
	EnterCriticalSection(&m_cs);
	if (m_actionList.size() > 0) {
		action = m_actionList.front();
		m_actionList.pop_front();
		bRet = true;
	}
	LeaveCriticalSection(&m_cs);
	return bRet;
}

void CRechargeWorker::NotifyMainWnd(UINT msg, WPARAM wParam, LPARAM lParam)
{
	PostMessage(m_hWnd, msg, wParam, lParam);
}

DWORD WINAPI CRechargeWorker::RechargeThread(void * param)
{
	CRechargeWorker *pWorker = (CRechargeWorker *)param;
	DWORD dwWaitResult;

	while (!pWorker->m_bExit) {
		dwWaitResult = WaitForSingleObject(pWorker->m_hSemaphore, 100);
		switch (dwWaitResult)
		{
		case WAIT_OBJECT_0:
		{
			RechargeAction action;
			if (pWorker->GetWork(action)) {
				switch (action.type)
				{
				case ACTION_RECHARGE:
				{
					//Sleep(10000);
					std::string response;
					std::wstring *pMessage = new std::wstring(_T("δ֪����"));
					bool bRet = false;
   					bRet = pWorker->m_scoreHttp.Recharge(action.uid, action.money, action.gift, response);
					if (bRet) {
						rapidjson::Document doc;
						doc.Parse(response.c_str());
						if (doc.HasMember("status_code") && doc["status_code"] == 400) {
							if (doc["message"].IsString()) {
								*pMessage = CUtils::UTF8ToUnicode(doc["message"].GetString());
							}
							//MessageBox(NULL, msg.c_str(), _T("��ʾ"), MB_OK);
							bRet = false;
						}
						else {
							std::string strStatus;
							strStatus = ("���id��") + action.uid + ("����ֵ��")
								+ action.money + ("�����ͣ�") + action.gift;
							*pMessage = CUtils::ANSIToUnicode(strStatus.c_str());
							std::string rid, agency, userId, money, gift;
							rapidjson::Value rechargeData;
							rechargeData = doc["data"];
							rid = rechargeData["rid"].GetString();
							agency = rechargeData["agency_name"].GetString();
							userId = action.uid;
							money = rechargeData["money"].GetString();
							gift = rechargeData["gift"].GetString();
							pWorker->m_excelHelper.RecordRecharge(rid, agency, userId, money, gift);
							bRet = true;
						}
					}
					pWorker->NotifyMainWnd(WM_RECHARGE, bRet, (LPARAM)pMessage);
				}
				break;
				case ACTION_ROLLBACK:
				{
					bool bRet = false;
					std::string response;
					std::wstring *pMessage = new std::wstring(_T("δ֪����"));
					if (pWorker->m_scoreHttp.rollBack(action.recordId, response)) {
						//MessageBox(NULL, _T("����ʧ��"), _T("��ʾ"), MB_OK);
						rapidjson::Document doc;
						doc.Parse(response.c_str());
						if (doc.HasMember("status_code") && doc["status_code"] == 400) {
							if (doc["message"].IsString()) {
								*pMessage = CUtils::UTF8ToUnicode(doc["message"].GetString());
							}
							//MessageBox(NULL, msg.c_str(), _T("��ʾ"), MB_OK);
							bRet = false;
						}
						else {
							bRet = true;
							if (doc.HasMember("message") && doc["message"].IsString()) {
								*pMessage = CUtils::UTF8ToUnicode(doc["message"].GetString());
							}
							pWorker->m_excelHelper.RollBack(action.uid, action.recordId, action.agency);
						}
						std::string strStatus;
						strStatus = ("���id��") + action.uid + ("����ֵ��")
							+ action.money + ("�����ͣ�") + action.gift;
						*pMessage = CUtils::ANSIToUnicode(strStatus.c_str());
					}
					pWorker->NotifyMainWnd(WM_ROLLBACK, bRet, (LPARAM)pMessage);
				}
				break;
				case ACTION_GET_RECENT:
				{
					std::string response;
					std::vector<RecentRecordData> *pRecordList = action.pRecordList;
					if (pWorker->m_scoreHttp.getRecent10Record(response)) {
						if (pWorker->m_parser.ParseRecent10(response, *pRecordList)) {
							pWorker->NotifyMainWnd(WM_RECENT, true, (LPARAM)pRecordList);
							break;
						}
					}
					pWorker->NotifyMainWnd(WM_RECENT, false, NULL);
				}
				break;
				default:
					break;
				}
			}
		}
			break;
		case WAIT_TIMEOUT:
			break;
		default:
			break;
		}
	}
	return 0;
}
